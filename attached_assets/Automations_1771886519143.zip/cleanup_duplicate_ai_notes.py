#!/usr/bin/env python3
"""
Duplicate AI Vetting Notes Cleanup

Finds and deletes duplicate "AI Vetting - Not Recommended" notes where
multiple notes are added within 60 minutes of each other (chained).

Logic:
1. Find all candidates with "AI Vetting - Not Recommended" notes from last 5 days
2. Group by candidate
3. Sort notes by dateAdded (oldest first)
4. Keep the ORIGINAL (first/oldest) note
5. Delete all subsequent notes that form a "chain" (each < 60 min from previous)

Usage:
  python3 cleanup_duplicate_ai_notes.py --dry-run            # Preview without deleting
  python3 cleanup_duplicate_ai_notes.py --execute            # Actually delete duplicates
  python3 cleanup_duplicate_ai_notes.py --dry-run --days 10  # Look back 10 days
"""

import sys
import os
import requests
import logging
import argparse
from datetime import datetime, timedelta
from collections import defaultdict

# Add src to path
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from integrations.bullhorn_client import BullhornClient

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# Configuration
TARGET_ACTION = "AI Vetting - Not Recommended"
CHAIN_WINDOW_MINUTES = 60


def timestamp_to_datetime(timestamp_ms: int) -> datetime:
    """Convert Bullhorn millisecond timestamp to datetime."""
    return datetime.fromtimestamp(timestamp_ms / 1000)


def get_recent_candidates(client: BullhornClient, count: int = 500) -> list:
    """Get recently modified candidates."""
    url = f"{client.rest_url}search/Candidate"
    params = {
        "query": "id:[1 TO *]",
        "fields": "id",
        "count": count,
        "sort": "-dateLastModified"
    }
    
    try:
        resp = requests.get(url, headers=client.get_headers(), params=params)
        if resp.status_code == 401:
            client.connect()
            resp = requests.get(url, headers=client.get_headers(), params=params)
        resp.raise_for_status()
        return [c.get("id") for c in resp.json().get("data", [])]
    except Exception as e:
        logger.error(f"Failed to fetch candidates: {e}")
        return []


def get_candidate_notes(client: BullhornClient, candidate_id: int) -> list:
    """Fetch all notes for a candidate via entity endpoint."""
    url = f"{client.rest_url}entity/Candidate/{candidate_id}/notes"
    params = {
        "fields": "id,action,dateAdded,comments",
        "count": 100
    }
    
    try:
        resp = requests.get(url, headers=client.get_headers(), params=params)
        if resp.status_code == 401:
            client.connect()
            resp = requests.get(url, headers=client.get_headers(), params=params)
        resp.raise_for_status()
        return resp.json().get("data", [])
    except Exception as e:
        return []


def search_ai_vetting_notes(client: BullhornClient, days_back: int = 5, max_candidates: int = 500, specific_ids: list = None) -> list:
    """
    Search for 'AI Vetting - Not Recommended' notes from candidates.
    Uses candidate-iteration approach since direct Note search is limited.
    
    Args:
        client: BullhornClient instance
        days_back: Number of days to look back
        max_candidates: Max candidates to scan when doing full search
        specific_ids: If provided, only scan these candidate IDs
    """
    cutoff_date = datetime.now() - timedelta(days=days_back)
    cutoff_timestamp = int(cutoff_date.timestamp() * 1000)
    
    # Determine which candidates to scan
    if specific_ids:
        candidate_ids = specific_ids
        logger.info(f"Scanning {len(candidate_ids)} specific candidates...")
    else:
        logger.info(f"Fetching up to {max_candidates} recently modified candidates...")
        candidate_ids = get_recent_candidates(client, max_candidates)
        logger.info(f"Got {len(candidate_ids)} candidates to scan")
    
    notes = []
    candidates_with_notes = 0
    
    for i, cid in enumerate(candidate_ids):
        cand_notes = get_candidate_notes(client, cid)
        
        # Filter to target action and date range
        for note in cand_notes:
            if (note.get("action") == TARGET_ACTION and 
                note.get("dateAdded", 0) > cutoff_timestamp):
                notes.append({
                    "id": note["id"],
                    "action": note["action"],
                    "dateAdded": note["dateAdded"],
                    "candidate_id": cid,
                    "comments": note.get("comments", "")[:100]
                })
        
        if len([n for n in cand_notes if n.get("action") == TARGET_ACTION]) > 0:
            candidates_with_notes += 1
        
        if (i + 1) % 50 == 0:
            logger.info(f"Scanned {i + 1}/{len(candidate_ids)} candidates, found {len(notes)} matching notes...")
    
    logger.info(f"Found {len(notes)} '{TARGET_ACTION}' notes from last {days_back} days across {candidates_with_notes} candidates")
    return notes


def get_candidate_info(client: BullhornClient, candidate_id: int) -> dict:
    """Fetch candidate name for display."""
    url = f"{client.rest_url}entity/Candidate/{candidate_id}"
    params = {"fields": "id,firstName,lastName,email"}
    try:
        resp = requests.get(url, headers=client.get_headers(), params=params)
        if resp.status_code == 401:
            client.connect()
            resp = requests.get(url, headers=client.get_headers(), params=params)
        resp.raise_for_status()
        data = resp.json().get("data", {})
        return {
            "id": candidate_id,
            "name": f"{data.get('firstName', '')} {data.get('lastName', '')}".strip(),
            "email": data.get("email", "N/A")
        }
    except:
        return {"id": candidate_id, "name": f"Candidate {candidate_id}", "email": "N/A"}


def find_duplicates_to_delete(notes: list) -> dict:
    """
    Group notes by candidate and identify duplicates based on 60-minute chain rule.
    
    Returns dict: {candidate_id: {"keep": [note], "delete": [notes...]}}
    """
    # Group by candidate
    by_candidate = defaultdict(list)
    for note in notes:
        by_candidate[note["candidate_id"]].append(note)
    
    results = {}
    
    for candidate_id, candidate_notes in by_candidate.items():
        if len(candidate_notes) < 2:
            # Only one note, nothing to delete
            continue
        
        # Sort by dateAdded (oldest first)
        candidate_notes.sort(key=lambda x: x["dateAdded"])
        
        # Always keep the first (oldest) note
        keep = [candidate_notes[0]]
        delete = []
        
        # Check subsequent notes for chaining
        prev_note = candidate_notes[0]
        
        for i in range(1, len(candidate_notes)):
            current_note = candidate_notes[i]
            
            prev_time = timestamp_to_datetime(prev_note["dateAdded"])
            current_time = timestamp_to_datetime(current_note["dateAdded"])
            
            gap_minutes = (current_time - prev_time).total_seconds() / 60
            
            if gap_minutes < CHAIN_WINDOW_MINUTES:
                # Part of the chain - mark for deletion
                delete.append({
                    **current_note,
                    "gap_minutes": round(gap_minutes, 1),
                    "datetime": current_time.strftime("%Y-%m-%d %H:%M:%S")
                })
            else:
                # Gap is too large - this note starts a new independent entry
                # Keep this note as well
                keep.append(current_note)
            
            # Update prev_note for next iteration
            prev_note = current_note
        
        if delete:
            results[candidate_id] = {
                "keep": keep,
                "delete": delete
            }
    
    return results


def delete_note(client: BullhornClient, note_id: int) -> bool:
    """Soft-delete a note by setting isDeleted=true."""
    url = f"{client.rest_url}entity/Note/{note_id}"
    payload = {"isDeleted": True}
    
    try:
        resp = requests.post(url, headers=client.get_headers(), json=payload)
        if resp.status_code == 401:
            client.connect()
            resp = requests.post(url, headers=client.get_headers(), json=payload)
        resp.raise_for_status()
        return True
    except Exception as e:
        logger.error(f"Failed to delete note {note_id}: {e}")
        return False


def main():
    parser = argparse.ArgumentParser(
        description="Cleanup duplicate AI Vetting notes from Bullhorn",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=__doc__
    )
    parser.add_argument("--dry-run", action="store_true", help="Preview duplicates without deleting")
    parser.add_argument("--execute", action="store_true", help="Actually delete the duplicate notes")
    parser.add_argument("--days", type=int, default=5, help="Number of days to look back (default: 5)")
    parser.add_argument("--candidate-ids", type=str, help="Comma-separated candidate IDs to check (e.g., 4585101,4585102)")
    parser.add_argument("--max-candidates", type=int, default=200, help="Max candidates to scan in full mode (default: 200)")
    
    args = parser.parse_args()
    
    if not args.dry_run and not args.execute:
        print("Error: Must specify --dry-run or --execute")
        parser.print_help()
        sys.exit(1)
    
    # Parse candidate IDs if provided
    specific_ids = None
    if args.candidate_ids:
        specific_ids = [int(x.strip()) for x in args.candidate_ids.split(",")]
    
    print("=" * 80)
    print("DUPLICATE AI VETTING NOTES CLEANUP")
    print(f"Target Action: {TARGET_ACTION}")
    print(f"Chain Window: {CHAIN_WINDOW_MINUTES} minutes")
    print(f"Looking back: {args.days} days")
    if specific_ids:
        print(f"Candidates: {specific_ids}")
    else:
        print(f"Scanning up to {args.max_candidates} recent candidates")
    print(f"Mode: {'DRY RUN (preview only)' if args.dry_run else 'EXECUTE (will delete)'}")
    print("=" * 80)
    print()
    
    # Connect to Bullhorn
    logger.info("Connecting to Bullhorn...")
    client = BullhornClient()
    client.connect()
    logger.info("Connected!")
    
    # Search for notes
    logger.info(f"Searching for '{TARGET_ACTION}' notes from last {args.days} days...")
    notes = search_ai_vetting_notes(
        client, 
        days_back=args.days, 
        max_candidates=args.max_candidates,
        specific_ids=specific_ids
    )
    
    if not notes:
        print("\nNo matching notes found. Nothing to clean up.")
        return
    
    # Find duplicates
    logger.info("Analyzing notes for duplicates...")
    duplicates = find_duplicates_to_delete(notes)
    
    if not duplicates:
        print("\nNo duplicate chains found. All notes appear to be unique (>60 min apart).")
        return
    
    # Calculate totals
    total_delete = sum(len(d["delete"]) for d in duplicates.values())
    total_keep = sum(len(d["keep"]) for d in duplicates.values())
    
    print()
    print("=" * 80)
    print(f"FOUND {total_delete} DUPLICATE NOTES TO DELETE across {len(duplicates)} candidates")
    print(f"Will keep {total_keep} original notes")
    print("=" * 80)
    print()
    
    # Display details
    for candidate_id, data in duplicates.items():
        cand_info = get_candidate_info(client, candidate_id)
        
        print(f"\n📋 Candidate: {cand_info['name']} (ID: {candidate_id})")
        print(f"   Email: {cand_info['email']}")
        print(f"   Notes to KEEP: {len(data['keep'])}")
        print(f"   Notes to DELETE: {len(data['delete'])}")
        
        # Show the original note being kept
        for keep_note in data["keep"]:
            keep_time = timestamp_to_datetime(keep_note["dateAdded"]).strftime("%Y-%m-%d %H:%M:%S")
            print(f"   ✅ KEEP: Note ID {keep_note['id']} ({keep_time})")
        
        # Show notes to delete
        for del_note in data["delete"]:
            print(f"   ❌ DELETE: Note ID {del_note['id']} ({del_note['datetime']}) - {del_note['gap_minutes']} min after previous")
    
    print()
    
    # Execute or dry-run
    if args.dry_run:
        print("=" * 80)
        print("DRY RUN COMPLETE - No notes were deleted.")
        print(f"To delete these {total_delete} duplicate notes, run with --execute")
        print("=" * 80)
    
    elif args.execute:
        print("=" * 80)
        print(f"EXECUTING DELETE of {total_delete} notes...")
        print("=" * 80)
        
        deleted = 0
        failed = 0
        
        for candidate_id, data in duplicates.items():
            for note in data["delete"]:
                note_id = note["id"]
                if delete_note(client, note_id):
                    logger.info(f"✅ Deleted note {note_id}")
                    deleted += 1
                else:
                    logger.error(f"❌ Failed to delete note {note_id}")
                    failed += 1
        
        print()
        print("=" * 80)
        print(f"DELETION COMPLETE: {deleted} deleted, {failed} failed")
        print("=" * 80)


if __name__ == "__main__":
    main()
