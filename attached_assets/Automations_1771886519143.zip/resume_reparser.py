#!/usr/bin/env python3
"""
Resume Re-Parser Automation

Finds candidates with:
1. Empty/missing description field (resume not parsed)
2. But have resume file attachments

Then re-parses using OpenAI Vision for image-based PDFs or Bullhorn's parser for text PDFs.

Usage:
  python3 resume_reparser.py --dry-run              # Preview candidates needing re-parse
  python3 resume_reparser.py --execute              # Actually parse and update
  python3 resume_reparser.py --execute --days 5     # Only check last 5 days (default)
  
Designed to run every 2-3 hours via cron or scheduler.
"""

import sys
import os
import base64
import requests
import logging
import argparse
from datetime import datetime, timedelta

# Add src to path
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from integrations.bullhorn_client import BullhornClient
from openai import OpenAI

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)


def get_candidates_missing_description(client: BullhornClient, days_back: int = 5, limit: int = 100) -> list:
    """
    Find candidates added in the last N days with empty description but with file attachments.
    """
    # Calculate timestamp for N days ago
    cutoff = datetime.now() - timedelta(days=days_back)
    cutoff_ms = int(cutoff.timestamp() * 1000)
    
    # Search for recently added candidates with empty description
    # Using -description:[* TO *] to find null/empty description fields
    url = f"{client.rest_url}search/Candidate"
    params = {
        "query": f"dateAdded:[{cutoff_ms} TO *] AND -description:[* TO *]",
        "fields": "id,firstName,lastName,email,description,dateAdded",
        "count": limit,
        "sort": "-dateAdded"
    }
    
    try:
        resp = requests.get(url, headers=client.get_headers(), params=params)
        if resp.status_code == 401:
            client.connect()
            resp = requests.get(url, headers=client.get_headers(), params=params)
        resp.raise_for_status()
        
        data = resp.json()
        candidates = data.get("data", [])
        total = data.get("total", 0)
        logger.info(f"Found {total} candidates with empty description in last {days_back} days (showing {len(candidates)})")
        
        return candidates
        
    except Exception as e:
        logger.error(f"Failed to search candidates: {e}")
        return []


def get_resume_file(client: BullhornClient, candidate_id: int) -> dict:
    """
    Get the most recent resume file attachment for a candidate.
    Returns dict with file_id, name, content_type, or None if no resume found.
    """
    url = f"{client.rest_url}entity/Candidate/{candidate_id}/fileAttachments"
    params = {"fields": "id,name,type,contentType,dateAdded"}
    
    try:
        resp = requests.get(url, headers=client.get_headers(), params=params)
        if resp.status_code == 401:
            client.connect()
            resp = requests.get(url, headers=client.get_headers(), params=params)
        resp.raise_for_status()
        
        files = resp.json().get("data", [])
        
        # Find resume files (type = 'Resume' or filename contains resume-like patterns)
        resume_files = [
            f for f in files 
            if f.get("type", "").lower() == "resume" 
            or "resume" in f.get("name", "").lower()
            or f.get("name", "").lower().endswith((".pdf", ".doc", ".docx"))
        ]
        
        if not resume_files:
            return None
        
        # Return most recent
        resume_files.sort(key=lambda x: x.get("dateAdded", 0), reverse=True)
        return resume_files[0]
        
    except Exception as e:
        logger.warning(f"Failed to get files for candidate {candidate_id}: {e}")
        return None


def download_file(client: BullhornClient, candidate_id: int, file_id: int) -> bytes:
    """Download file content from Bullhorn."""
    url = f"{client.rest_url}file/Candidate/{candidate_id}/{file_id}"
    
    try:
        resp = requests.get(url, headers=client.get_headers())
        if resp.status_code == 401:
            client.connect()
            resp = requests.get(url, headers=client.get_headers())
        resp.raise_for_status()
        return resp.content
    except Exception as e:
        logger.error(f"Failed to download file {file_id}: {e}")
        return None


def extract_text_with_openai(file_content: bytes, filename: str) -> str:
    """
    Use OpenAI to extract text from a resume file.
    For PDFs, uses base64 encoding and asks GPT-4o to extract text.
    """
    import tempfile
    openai_client = OpenAI()
    
    # For DOC/DOCX files, try direct text extraction first
    ext = filename.lower().split(".")[-1] if "." in filename else "pdf"
    
    try:
        # Upload file to OpenAI and use file parsing
        with tempfile.NamedTemporaryFile(suffix=f".{ext}", delete=False) as tmp:
            tmp.write(file_content)
            tmp_path = tmp.name
        
        # Upload file
        with open(tmp_path, "rb") as f:
            file_obj = openai_client.files.create(file=f, purpose="assistants")
        
        # Use chat completion with file reference
        response = openai_client.chat.completions.create(
            model="gpt-4o",
            messages=[
                {
                    "role": "system",
                    "content": """You are a resume text extractor. Your job is to extract ALL text content from the provided resume document.
                    
Return the COMPLETE text content, formatted with proper line breaks and sections.
Include: Name, Contact Info, Summary/Objective, Work Experience, Education, Skills, Certifications.

Do NOT summarize - extract the actual full text. If the document appears to be image-based or scanned, do your best to describe what you can see."""
                },
                {
                    "role": "user",
                    "content": [
                        {
                            "type": "text",
                            "text": f"Please extract all text from this resume file: {filename}"
                        },
                        {
                            "type": "file",
                            "file": {"file_id": file_obj.id}
                        }
                    ]
                }
            ],
            max_tokens=4000
        )
        
        # Clean up
        os.unlink(tmp_path)
        try:
            openai_client.files.delete(file_obj.id)
        except:
            pass
        
        extracted_text = response.choices[0].message.content
        return extracted_text.strip() if extracted_text else None
        
    except Exception as e:
        logger.error(f"OpenAI extraction failed: {e}")
        # Fallback: Try basic text extraction
        try:
            text = file_content.decode('utf-8', errors='ignore')
            if len(text) > 100 and text.isprintable():
                return text[:10000]
        except:
            pass
        return None


def try_bullhorn_parse(client: BullhornClient, file_content: bytes, filename: str) -> str:
    """
    Try Bullhorn's native parser first. Returns description text if successful.
    NOTE: Bullhorn's parser often returns binary data - this function validates the output.
    """
    parse_url = f"{client.rest_url}resume/parseToCandidate"
    headers = {"BhRestToken": client.get_headers()["BhRestToken"]}
    
    # Determine format from filename
    ext = filename.lower().split(".")[-1] if "." in filename else "pdf"
    
    files = {"file": (filename, file_content, f"application/{ext}")}
    params = {"format": ext, "populateDescription": "text"}
    
    try:
        resp = requests.post(parse_url, headers=headers, params=params, files=files)
        if resp.status_code == 200:
            data = resp.json()
            desc = data.get("candidate", {}).get("description", "")
            
            # Validate it's real text, not binary junk
            if desc and len(desc) > 100:
                # Reject if it contains binary/base64 markers
                if any(marker in desc for marker in ["fileContent", "base64", "JVBERi", "0M8R4K", "PK\x03\x04"]):
                    logger.warning("Bullhorn returned binary data, not text")
                    return None
                return desc
                
    except Exception as e:
        logger.warning(f"Bullhorn parse failed: {e}")
    
    return None


def update_candidate_description(client: BullhornClient, candidate_id: int, description: str) -> bool:
    """Update the candidate's description field."""
    url = f"{client.rest_url}entity/Candidate/{candidate_id}"
    payload = {"description": description}
    
    try:
        resp = requests.post(url, headers=client.get_headers(), json=payload)
        if resp.status_code == 401:
            client.connect()
            resp = requests.post(url, headers=client.get_headers(), json=payload)
        
        if resp.status_code == 200:
            return True
        else:
            logger.error(f"Failed to update candidate {candidate_id}: {resp.status_code} - {resp.text[:200]}")
            return False
            
    except Exception as e:
        logger.error(f"Update failed for candidate {candidate_id}: {e}")
        return False


def main():
    parser = argparse.ArgumentParser(description="Re-parse resumes for candidates with missing descriptions")
    parser.add_argument("--dry-run", action="store_true", help="Preview without making changes")
    parser.add_argument("--execute", action="store_true", help="Actually parse and update")
    parser.add_argument("--days", type=int, default=5, help="Days back to check (default: 5)")
    parser.add_argument("--limit", type=int, default=100, help="Max candidates to process (default: 100)")
    
    args = parser.parse_args()
    
    if not args.dry_run and not args.execute:
        print("Error: Must specify --dry-run or --execute")
        parser.print_help()
        sys.exit(1)
    
    # Connect to Bullhorn
    logger.info("Connecting to Bullhorn...")
    client = BullhornClient()
    client.connect()
    logger.info("Connected!")
    
    # Find candidates with missing descriptions
    candidates = get_candidates_missing_description(client, args.days, args.limit)
    
    if not candidates:
        logger.info("No candidates found with missing descriptions. All good!")
        return
    
    # Process each candidate
    results = {"processed": 0, "updated": 0, "no_file": 0, "parse_failed": 0}
    
    for cand in candidates:
        cid = cand.get("id")
        name = f"{cand.get('firstName', '')} {cand.get('lastName', '')}"
        
        print(f"\n{'='*60}")
        print(f"Candidate: {name} (ID: {cid})")
        
        # Check for resume file
        resume_file = get_resume_file(client, cid)
        if not resume_file:
            print(f"  No resume file attached - skipping")
            results["no_file"] += 1
            continue
        
        print(f"  Resume file: {resume_file.get('name')} (ID: {resume_file.get('id')})")
        
        if args.dry_run:
            print(f"  [DRY RUN] Would attempt to parse and update description")
            results["processed"] += 1
            continue
        
        # Download the file
        file_content = download_file(client, cid, resume_file.get("id"))
        if not file_content:
            print(f"  Failed to download file - skipping")
            results["parse_failed"] += 1
            continue
        
        # Try Bullhorn's parser first
        print(f"  Trying Bullhorn parser...")
        description = try_bullhorn_parse(client, file_content, resume_file.get("name", "resume.pdf"))
        
        # If Bullhorn fails, use OpenAI Vision
        if not description:
            print(f"  Bullhorn parser returned empty, trying OpenAI Vision...")
            description = extract_text_with_openai(file_content, resume_file.get("name", "resume.pdf"))
        
        if description:
            print(f"  Extracted {len(description)} chars of text")
            if update_candidate_description(client, cid, description):
                print(f"  ✓ Updated description successfully!")
                results["updated"] += 1
            else:
                print(f"  ✗ Failed to update description")
                results["parse_failed"] += 1
        else:
            print(f"  ✗ Could not extract text from resume")
            results["parse_failed"] += 1
        
        results["processed"] += 1
    
    # Summary
    print(f"\n{'='*60}")
    print("SUMMARY")
    print(f"{'='*60}")
    print(f"  Candidates checked: {len(candidates)}")
    print(f"  Processed: {results['processed']}")
    print(f"  Updated: {results['updated']}")
    print(f"  No file attached: {results['no_file']}")
    print(f"  Parse failed: {results['parse_failed']}")


if __name__ == "__main__":
    main()
