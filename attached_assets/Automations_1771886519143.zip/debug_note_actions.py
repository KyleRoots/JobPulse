#!/usr/bin/env python3
"""
Quick diagnostic: What Note actions actually exist for candidates on these jobs?
Samples first 10 candidates from each job, fetches ALL their notes, and prints unique actions.
"""
import os, sys, time, requests
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', '..'))
from integrations.bullhorn_client import BullhornClient

JOB_IDS = [34637, 34638, 34639]

client = BullhornClient()
client.connect()

all_actions = set()

for job_id in JOB_IDS:
    print(f"\n--- Job {job_id} ---")
    # Get first 10 submissions
    url = f"{client.rest_url}search/JobSubmission"
    params = {
        "query": f"jobOrder.id:{job_id} AND isDeleted:0",
        "fields": "id,candidate(id,firstName,lastName)",
        "count": 10,
        "sort": "-dateAdded"
    }
    resp = requests.get(url, headers=client.get_headers(), params=params)
    subs = resp.json().get("data", [])
    
    for sub in subs:
        cand = sub.get("candidate", {})
        cid = cand.get("id")
        if not cid:
            continue
        
        # Fetch up to 100 notes
        note_url = f"{client.rest_url}search/Note"
        note_params = {
            "query": f"candidates.id:{cid} AND isDeleted:0",
            "fields": "id,action,dateAdded,comments",
            "count": 100,
            "sort": "-dateAdded"
        }
        nresp = requests.get(note_url, headers=client.get_headers(), params=note_params)
        notes = nresp.json().get("data", [])
        
        actions = set(n.get("action", "(none)") for n in notes)
        all_actions.update(actions)
        
        print(f"  Candidate {cid} ({cand.get('firstName')} {cand.get('lastName')}): {len(notes)} notes")
        for a in sorted(actions):
            print(f"    → {repr(a)}")
        
        time.sleep(0.1)

print(f"\n\n=== ALL UNIQUE NOTE ACTIONS FOUND ===")
for a in sorted(all_actions):
    print(f"  {repr(a)}")
