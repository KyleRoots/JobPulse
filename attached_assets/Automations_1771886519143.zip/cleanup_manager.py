"""
Scout Genius - Cleanup Manager

Automated backend optimization to keep the application tidy, clean, and optimized.
Similar to JobPulse's cleanup automation.

Features:
- Log rotation and archival
- Stale data cleanup
- Memory file optimization (compact JSON files)
- Orphan file detection
- Health checks and reports
"""

import os
import json
import gzip
import shutil
import logging
from datetime import datetime, timedelta
from pathlib import Path
from typing import Dict, List, Any, Optional

# Setup logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("CleanupManager")


class CleanupManager:
    """
    Manages automated cleanup and optimization tasks for Scout Genius.
    """
    
    def __init__(self, base_path: str = None):
        """
        Initialize the cleanup manager.
        
        Args:
            base_path: Base path for the Scout application. Defaults to parent of this file.
        """
        if base_path is None:
            base_path = Path(__file__).parent.parent.parent
        self.base_path = Path(base_path)
        
        # Configuration
        self.config = {
            # Log retention in days
            "log_retention_days": 30,
            # Conversation data retention in days
            "conversation_retention_days": 90,
            # Test scenario retention in days
            "test_scenario_retention_days": 7,
            # Maximum log file size before rotation (MB)
            "max_log_size_mb": 50,
            # Directories to clean
            "log_dirs": ["logs", "src/logs"],
            "data_dirs": ["data", "src/data"],
            "temp_dirs": ["tmp", ".tmp", "__pycache__"],
        }
        
        # Track cleanup results
        self.results = {
            "started_at": None,
            "completed_at": None,
            "logs_archived": 0,
            "files_deleted": 0,
            "space_freed_mb": 0,
            "errors": []
        }
    
    def run_full_cleanup(self) -> Dict[str, Any]:
        """
        Run all cleanup tasks.
        
        Returns:
            Dict with cleanup results and statistics
        """
        self.results["started_at"] = datetime.now().isoformat()
        logger.info("Starting full cleanup...")
        
        try:
            # 1. Rotate and archive logs
            self._rotate_logs()
            
            # 2. Clean stale data
            self._clean_stale_data()
            
            # 3. Optimize JSON files
            self._optimize_json_files()
            
            # 4. Clean temp directories
            self._clean_temp_dirs()
            
            # 5. Clean pycache
            self._clean_pycache()
            
            # 6. Generate health report
            health = self._generate_health_report()
            
        except Exception as e:
            logger.error(f"Cleanup error: {e}")
            self.results["errors"].append(str(e))
        
        self.results["completed_at"] = datetime.now().isoformat()
        logger.info(f"Cleanup completed. Space freed: {self.results['space_freed_mb']:.2f} MB")
        
        return self.results
    
    def _rotate_logs(self):
        """Rotate and archive old log files."""
        logger.info("Rotating logs...")
        
        for log_dir in self.config["log_dirs"]:
            log_path = self.base_path / log_dir
            if not log_path.exists():
                continue
            
            for log_file in log_path.glob("*.log"):
                try:
                    # Check file size
                    size_mb = log_file.stat().st_size / (1024 * 1024)
                    
                    if size_mb > self.config["max_log_size_mb"]:
                        # Archive the log
                        archive_name = f"{log_file.stem}_{datetime.now().strftime('%Y%m%d_%H%M%S')}.log.gz"
                        archive_path = log_path / "archive" / archive_name
                        archive_path.parent.mkdir(parents=True, exist_ok=True)
                        
                        # Compress and save
                        with open(log_file, 'rb') as f_in:
                            with gzip.open(archive_path, 'wb') as f_out:
                                shutil.copyfileobj(f_in, f_out)
                        
                        # Clear original log
                        log_file.write_text("")
                        
                        self.results["logs_archived"] += 1
                        self.results["space_freed_mb"] += size_mb
                        logger.info(f"Archived: {log_file.name} ({size_mb:.2f} MB)")
                
                except Exception as e:
                    self.results["errors"].append(f"Log rotation error: {e}")
        
        # Clean old archives
        self._clean_old_archives()
    
    def _clean_old_archives(self):
        """Remove archived logs older than retention period."""
        retention_cutoff = datetime.now() - timedelta(days=self.config["log_retention_days"])
        
        for log_dir in self.config["log_dirs"]:
            archive_path = self.base_path / log_dir / "archive"
            if not archive_path.exists():
                continue
            
            for archive_file in archive_path.glob("*.gz"):
                try:
                    mtime = datetime.fromtimestamp(archive_file.stat().st_mtime)
                    if mtime < retention_cutoff:
                        size_mb = archive_file.stat().st_size / (1024 * 1024)
                        archive_file.unlink()
                        self.results["files_deleted"] += 1
                        self.results["space_freed_mb"] += size_mb
                        logger.info(f"Deleted old archive: {archive_file.name}")
                except Exception as e:
                    self.results["errors"].append(f"Archive cleanup error: {e}")
    
    def _clean_stale_data(self):
        """Clean stale conversation and test data."""
        logger.info("Cleaning stale data...")
        
        # Clean old conversation data
        conversation_cutoff = datetime.now() - timedelta(days=self.config["conversation_retention_days"])
        
        for data_dir in self.config["data_dirs"]:
            data_path = self.base_path / data_dir
            if not data_path.exists():
                continue
            
            # Check for conversation files
            for json_file in data_path.glob("**/conversations*.json"):
                try:
                    self._clean_old_entries(json_file, conversation_cutoff, "timestamp")
                except Exception as e:
                    self.results["errors"].append(f"Conversation cleanup error: {e}")
    
    def _clean_old_entries(self, json_file: Path, cutoff: datetime, date_field: str):
        """Remove old entries from a JSON file."""
        try:
            with open(json_file, 'r') as f:
                data = json.load(f)
            
            if isinstance(data, list):
                original_count = len(data)
                data = [
                    item for item in data 
                    if self._parse_date(item.get(date_field, "")) >= cutoff
                ]
                removed = original_count - len(data)
                
                if removed > 0:
                    with open(json_file, 'w') as f:
                        json.dump(data, f, indent=2)
                    logger.info(f"Removed {removed} old entries from {json_file.name}")
        
        except Exception as e:
            logger.warning(f"Could not clean {json_file}: {e}")
    
    def _parse_date(self, date_str: str) -> datetime:
        """Parse an ISO date string."""
        try:
            return datetime.fromisoformat(date_str.replace('Z', '+00:00'))
        except:
            return datetime.min
    
    def _optimize_json_files(self):
        """Compact and optimize JSON files."""
        logger.info("Optimizing JSON files...")
        
        for data_dir in self.config["data_dirs"]:
            data_path = self.base_path / data_dir
            if not data_path.exists():
                continue
            
            for json_file in data_path.glob("**/*.json"):
                try:
                    original_size = json_file.stat().st_size
                    
                    with open(json_file, 'r') as f:
                        data = json.load(f)
                    
                    # Rewrite with minimal formatting
                    with open(json_file, 'w') as f:
                        json.dump(data, f, separators=(',', ':'))
                    
                    new_size = json_file.stat().st_size
                    saved = (original_size - new_size) / (1024 * 1024)
                    
                    if saved > 0.01:  # Only log if > 10KB saved
                        self.results["space_freed_mb"] += saved
                        logger.info(f"Optimized {json_file.name}: saved {saved:.2f} MB")
                
                except Exception as e:
                    self.results["errors"].append(f"JSON optimization error: {e}")
    
    def _clean_temp_dirs(self):
        """Clean temporary directories."""
        logger.info("Cleaning temp directories...")
        
        for temp_dir in self.config["temp_dirs"]:
            temp_path = self.base_path / temp_dir
            if temp_path.exists() and temp_path.is_dir():
                try:
                    size = sum(f.stat().st_size for f in temp_path.rglob('*') if f.is_file())
                    size_mb = size / (1024 * 1024)
                    
                    shutil.rmtree(temp_path)
                    temp_path.mkdir(exist_ok=True)
                    
                    self.results["space_freed_mb"] += size_mb
                    logger.info(f"Cleaned temp directory: {temp_dir} ({size_mb:.2f} MB)")
                except Exception as e:
                    self.results["errors"].append(f"Temp cleanup error: {e}")
    
    def _clean_pycache(self):
        """Remove all __pycache__ directories."""
        logger.info("Cleaning pycache...")
        
        for pycache in self.base_path.rglob("__pycache__"):
            if pycache.is_dir():
                try:
                    size = sum(f.stat().st_size for f in pycache.rglob('*') if f.is_file())
                    size_mb = size / (1024 * 1024)
                    
                    shutil.rmtree(pycache)
                    
                    self.results["files_deleted"] += 1
                    self.results["space_freed_mb"] += size_mb
                except Exception as e:
                    pass  # Silently ignore pycache errors
    
    def _generate_health_report(self) -> Dict[str, Any]:
        """Generate a health report for the application."""
        logger.info("Generating health report...")
        
        report = {
            "timestamp": datetime.now().isoformat(),
            "disk_usage": {},
            "file_counts": {},
            "recommendations": []
        }
        
        # Check disk usage
        for dir_name in ["src", "data", "logs"]:
            dir_path = self.base_path / dir_name
            if dir_path.exists():
                total_size = sum(f.stat().st_size for f in dir_path.rglob('*') if f.is_file())
                report["disk_usage"][dir_name] = f"{total_size / (1024 * 1024):.2f} MB"
                report["file_counts"][dir_name] = sum(1 for _ in dir_path.rglob('*') if _.is_file())
        
        # Add recommendations
        if self.results["errors"]:
            report["recommendations"].append("Review errors in cleanup log")
        
        return report


def run_cleanup():
    """Run cleanup as a standalone script."""
    manager = CleanupManager()
    results = manager.run_full_cleanup()
    
    print("\n" + "="*50)
    print("CLEANUP COMPLETE")
    print("="*50)
    print(f"Started: {results['started_at']}")
    print(f"Completed: {results['completed_at']}")
    print(f"Logs archived: {results['logs_archived']}")
    print(f"Files deleted: {results['files_deleted']}")
    print(f"Space freed: {results['space_freed_mb']:.2f} MB")
    
    if results['errors']:
        print(f"\nErrors ({len(results['errors'])}):")
        for error in results['errors'][:5]:
            print(f"  - {error}")
    
    return results


if __name__ == "__main__":
    run_cleanup()
