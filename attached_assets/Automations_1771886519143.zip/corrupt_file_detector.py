#!/usr/bin/env python3
"""
Corrupt Resume File Detector
=============================
Scans Bullhorn candidate records for corrupt/unreadable resume files.
Detection method: downloading the file via API - corrupt files return HTTP 500.

Usage:
    python corrupt_file_detector.py --days 30 --limit 500
    python corrupt_file_detector.py --from-date 2025-02-01 --to-date 2025-05-31 --limit 5000
    python corrupt_file_detector.py --all --limit 5000
"""

import sys
import os
import csv
import argparse
import logging
import time
from datetime import datetime, timedelta
from collections import defaultdict

sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))
import requests
from integrations.bullhorn_client import BullhornClient

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)


def get_candidates_with_files(client, start=0, count=100, days_back=None, from_date=None, to_date=None):
    """
    Get a batch of candidates filtered by date.
    Supports: days_back (relative) or from_date/to_date (explicit range).
    Note: Bullhorn Lucene only supports [X TO *], not [X TO Y] for dateAdded,
    so we use from_date in the query and filter by to_date client-side.
    Returns (candidates, total).
    """
    url = f"{client.rest_url}search/Candidate"
    
    if from_date:
        from_ms = int(from_date.timestamp() * 1000)
        query = f"dateAdded:[{from_ms} TO *]"
    elif days_back:
        cutoff = datetime.now() - timedelta(days=days_back)
        cutoff_ms = int(cutoff.timestamp() * 1000)
        query = f"dateAdded:[{cutoff_ms} TO *]"
    else:
        query = "isDeleted:0"
    
    params = {
        "query": query,
        "fields": "id,firstName,lastName,email,dateAdded",
        "count": count,
        "start": start,
        "sort": "dateAdded"  # Ascending so we can stop at to_date
    }
    
    try:
        resp = requests.get(url, headers=client.get_headers(), params=params)
        if resp.status_code == 401:
            client.connect()
            resp = requests.get(url, headers=client.get_headers(), params=params)
        resp.raise_for_status()
        
        data = resp.json()
        candidates = data.get("data", [])
        total = data.get("total", 0)
        
        # Client-side end date filter
        if to_date:
            to_ms = int(to_date.timestamp() * 1000)
            candidates = [c for c in candidates if c.get("dateAdded", 0) <= to_ms]
        
        return candidates, total
    except Exception as e:
        logger.error(f"Failed to search candidates: {e}")
        return [], 0


def get_file_attachments(client, candidate_id):
    """Get all file attachments for a candidate."""
    url = f"{client.rest_url}entity/Candidate/{candidate_id}/fileAttachments"
    params = {"fields": "id,name,type,contentType,dateAdded"}
    
    try:
        resp = requests.get(url, headers=client.get_headers(), params=params)
        if resp.status_code == 401:
            client.connect()
            resp = requests.get(url, headers=client.get_headers(), params=params)
        if resp.status_code == 200:
            return resp.json().get("data", [])
    except Exception:
        pass
    return []


def check_file_health(client, candidate_id, file_id):
    """
    Check if a file is corrupt by attempting to download it.
    Returns: ('ok', 'corrupt', 'empty', 'error') and details.
    """
    url = f"{client.rest_url}file/Candidate/{candidate_id}/{file_id}"
    
    try:
        resp = requests.get(url, headers=client.get_headers())
        
        if resp.status_code == 500:
            return "corrupt", "HTTP 500 - Internal error (file unreadable)"
        
        if resp.status_code == 404:
            return "missing", "HTTP 404 - File not found"
        
        if resp.status_code == 200:
            content = resp.content
            if len(content) == 0:
                return "empty", "File is 0 bytes"
            
            # Check for error JSON disguised as 200
            if content[:1] == b'{':
                try:
                    err = resp.json()
                    if "errorMessage" in err:
                        return "corrupt", f"Error response: {err['errorMessage']}"
                except:
                    pass
            
            return "ok", f"File OK ({len(content)} bytes)"
        
        return "error", f"HTTP {resp.status_code}"
    
    except Exception as e:
        return "error", f"Request failed: {str(e)}"


def main():
    parser = argparse.ArgumentParser(description="Detect corrupt resume files in Bullhorn")
    parser.add_argument("--days", type=int, default=None, help="Only check candidates added in the last N days")
    parser.add_argument("--from-date", type=str, default=None, help="Start date (YYYY-MM-DD), e.g. 2025-02-01")
    parser.add_argument("--to-date", type=str, default=None, help="End date (YYYY-MM-DD), e.g. 2025-05-31")
    parser.add_argument("--limit", type=int, default=500, help="Maximum candidates to check (default: 500)")
    parser.add_argument("--batch-size", type=int, default=100, help="Candidates per API batch (default: 100)")
    parser.add_argument("--output", type=str, default="corrupt_files_report.csv", help="Output CSV filename")
    parser.add_argument("--all", action="store_true", help="Check all candidates (no date filter)")
    args = parser.parse_args()

    # Parse date range
    from_date = None
    to_date = None
    days_back = args.days

    if args.from_date and args.to_date:
        from_date = datetime.strptime(args.from_date, "%Y-%m-%d")
        to_date = datetime.strptime(args.to_date, "%Y-%m-%d").replace(hour=23, minute=59, second=59)
        date_label = f"{args.from_date} to {args.to_date}"
    elif args.all:
        days_back = None
        date_label = "All time"
    elif days_back:
        date_label = f"Last {days_back} days"
    else:
        days_back = 365
        date_label = f"Last {days_back} days (default)"
    
    print("=" * 60)
    print("CORRUPT RESUME FILE DETECTOR")
    print("=" * 60)
    print(f"Date range: {date_label}")
    print(f"Max candidates to check: {args.limit}")
    print(f"Output file: {args.output}")
    print("=" * 60)
    
    # Connect to Bullhorn
    logger.info("Connecting to Bullhorn...")
    client = BullhornClient()
    client.connect()
    logger.info("Connected!")
    
    # Get initial count
    _, total_from_start = get_candidates_with_files(client, start=0, count=1, days_back=days_back,
                                                     from_date=from_date, to_date=None)
    if to_date:
        print(f"\nTotal candidates from start date: {total_from_start:,}")
        print(f"(Will stop at {args.to_date}, checking up to {args.limit:,})")
    else:
        print(f"\nTotal candidates in range: {total_from_start:,}")
        print(f"Will check up to: {min(args.limit, total_from_start):,}")
    print()
    
    # Tracking
    corrupt_files = []
    stats = {
        "candidates_checked": 0,
        "candidates_with_files": 0,
        "files_checked": 0,
        "files_ok": 0,
        "files_corrupt": 0,
        "files_empty": 0,
        "files_missing": 0,
        "files_error": 0,
        "candidates_no_files": 0,
    }
    
    # Process in batches
    checked = 0
    batch_start = 0
    hit_end_date = False
    
    while checked < args.limit and not hit_end_date:
        batch_count = min(args.batch_size, args.limit - checked)
        candidates, _ = get_candidates_with_files(client, start=batch_start, count=batch_count,
                                                     days_back=days_back, from_date=from_date, to_date=None)
        
        if not candidates:
            break
        
        for cand in candidates:
            if checked >= args.limit:
                break
            
            # Check if we've passed the end date (sorted ascending)
            if to_date and cand.get("dateAdded", 0) > int(to_date.timestamp() * 1000):
                hit_end_date = True
                break
            
            cand_id = cand["id"]
            name = f"{cand.get('firstName', '')} {cand.get('lastName', '')}".strip()
            stats["candidates_checked"] += 1
            checked += 1
            
            # Get files for this candidate
            files = get_file_attachments(client, cand_id)
            
            if not files:
                stats["candidates_no_files"] += 1
                continue
            
            stats["candidates_with_files"] += 1
            
            for f in files:
                file_id = f["id"]
                file_name = f.get("name", "unknown")
                stats["files_checked"] += 1
                
                # Check file health
                status, detail = check_file_health(client, cand_id, file_id)
                
                if status == "ok":
                    stats["files_ok"] += 1
                elif status == "corrupt":
                    stats["files_corrupt"] += 1
                    corrupt_files.append({
                        "candidate_id": cand_id,
                        "candidate_name": name,
                        "candidate_email": cand.get("email", ""),
                        "file_id": file_id,
                        "file_name": file_name,
                        "file_type": f.get("type", ""),
                        "content_type": f.get("contentType", ""),
                        "date_added": cand.get("dateAdded", ""),
                        "status": status,
                        "detail": detail,
                    })
                    print(f"  ❌ CORRUPT: {name} (ID: {cand_id}) - {file_name}")
                elif status == "empty":
                    stats["files_empty"] += 1
                    corrupt_files.append({
                        "candidate_id": cand_id,
                        "candidate_name": name,
                        "candidate_email": cand.get("email", ""),
                        "file_id": file_id,
                        "file_name": file_name,
                        "file_type": f.get("type", ""),
                        "content_type": f.get("contentType", ""),
                        "date_added": cand.get("dateAdded", ""),
                        "status": status,
                        "detail": detail,
                    })
                    print(f"  ⚠️  EMPTY: {name} (ID: {cand_id}) - {file_name}")
                elif status == "missing":
                    stats["files_missing"] += 1
                else:
                    stats["files_error"] += 1
                
                # Small delay to be gentle on the API
                time.sleep(0.1)
            
            # Progress update every 50 candidates
            if checked % 50 == 0:
                print(f"  ... checked {checked} candidates "
                      f"({stats['files_corrupt']} corrupt found so far)")
        
        batch_start += len(candidates)
        
        # Reconnect periodically to avoid token expiry
        if checked % 200 == 0:
            try:
                client.connect()
            except Exception:
                pass
    
    # Write CSV report
    if corrupt_files:
        output_path = os.path.join(os.path.dirname(__file__), "..", "..", args.output)
        with open(output_path, "w", newline="") as csvfile:
            writer = csv.DictWriter(csvfile, fieldnames=[
                "candidate_id", "candidate_name", "candidate_email",
                "file_id", "file_name", "file_type", "content_type",
                "date_added", "status", "detail"
            ])
            writer.writeheader()
            writer.writerows(corrupt_files)
        print(f"\n📄 Report saved: {os.path.abspath(output_path)}")
    
    # Print summary
    print("\n" + "=" * 60)
    print("SUMMARY")
    print("=" * 60)
    print(f"  Candidates checked:     {stats['candidates_checked']:,}")
    print(f"  Candidates with files:  {stats['candidates_with_files']:,}")
    print(f"  Candidates no files:    {stats['candidates_no_files']:,}")
    print(f"  ---")
    print(f"  Total files checked:    {stats['files_checked']:,}")
    print(f"  Files OK:               {stats['files_ok']:,}")
    print(f"  Files CORRUPT:          {stats['files_corrupt']:,}")
    print(f"  Files EMPTY:            {stats['files_empty']:,}")
    print(f"  Files MISSING:          {stats['files_missing']:,}")
    print(f"  Files ERROR:            {stats['files_error']:,}")
    
    corruption_rate = 0
    if stats['files_checked'] > 0:
        corruption_rate = (stats['files_corrupt'] + stats['files_empty']) / stats['files_checked'] * 100
    print(f"  ---")
    print(f"  Corruption rate:        {corruption_rate:.1f}%")
    
    # Monthly breakdown of corrupt files
    if corrupt_files:
        print(f"\n  MONTHLY BREAKDOWN:")
        monthly = defaultdict(lambda: {"corrupt": 0, "empty": 0})
        for cf in corrupt_files:
            ts = cf.get("date_added", 0)
            if ts:
                dt = datetime.fromtimestamp(ts / 1000)
                month_key = dt.strftime("%Y-%m")
                monthly[month_key][cf["status"]] += 1
        
        for month in sorted(monthly.keys()):
            counts = monthly[month]
            total_bad = counts["corrupt"] + counts["empty"]
            print(f"    {month}: {total_bad} bad files "
                  f"({counts['corrupt']} corrupt, {counts['empty']} empty)")
    
    print("=" * 60)


if __name__ == "__main__":
    main()
