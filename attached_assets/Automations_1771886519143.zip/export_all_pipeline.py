#!/usr/bin/env python3
"""
Scout Genius - Search for Notes with specific actions globally.
Also exports ALL pipeline candidates for jobs 34637/34638/34639 to CSV.
"""
import os, sys, csv, time, requests
from datetime import datetime

sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', '..'))
from integrations.bullhorn_client import BullhornClient

client = BullhornClient()
client.connect()

# ─── Search 1: Do qualifying notes exist ANYWHERE in Bullhorn? ───────────────

print("\n" + "=" * 70)
print("  SEARCH 1: Global search for qualifying Note actions")
print("=" * 70)

for action_text in ["Scout Screen - Qualified", "AI Vetting - Qualified", "Scout Screen", "AI Vetting"]:
    url = f"{client.rest_url}search/Note"
    params = {
        "query": f'action:"{action_text}" AND isDeleted:0',
        "fields": "id,action,dateAdded,candidates(id,firstName,lastName)",
        "count": 5,
        "sort": "-dateAdded"
    }
    resp = requests.get(url, headers=client.get_headers(), params=params)
    data = resp.json()
    total = data.get("total", 0)
    results = data.get("data", [])
    
    print(f"\n  Action: '{action_text}' → {total} notes found")
    for n in results[:3]:
        cands = n.get("candidates", {}).get("data", [])
        cand_info = ", ".join([f"{c.get('firstName')} {c.get('lastName')} (ID:{c.get('id')})" for c in cands[:2]])
        print(f"    Note {n['id']}: {n.get('action')} | {cand_info}")
    
    time.sleep(0.2)

# ─── Search 2: What note actions DO exist on these job candidates? ───────────

print("\n\n" + "=" * 70)
print("  SEARCH 2: Sample of actual note actions on these jobs' candidates")
print("=" * 70)

JOB_IDS = [34637, 34638, 34639]
all_actions = set()

for job_id in JOB_IDS:
    # Get older submissions (skip first 100 to find ones that may have been processed)
    url = f"{client.rest_url}search/JobSubmission"
    params = {
        "query": f"jobOrder.id:{job_id} AND isDeleted:0",
        "fields": "id,candidate(id,firstName,lastName)",
        "count": 5,
        "start": 200,  # Skip to older ones
        "sort": "-dateAdded"
    }
    resp = requests.get(url, headers=client.get_headers(), params=params)
    subs = resp.json().get("data", [])
    
    print(f"\n  Job {job_id} (checking older candidates, start=200):")
    for sub in subs:
        cand = sub.get("candidate", {})
        cid = cand.get("id")
        if not cid:
            continue
        
        note_url = f"{client.rest_url}search/Note"
        note_params = {
            "query": f"candidates.id:{cid} AND isDeleted:0",
            "fields": "id,action",
            "count": 50,
            "sort": "-dateAdded"
        }
        nresp = requests.get(note_url, headers=client.get_headers(), params=note_params)
        notes = nresp.json().get("data", [])
        actions = set(n.get("action", "(none)") for n in notes)
        all_actions.update(actions)
        
        print(f"    Candidate {cid} ({cand.get('firstName')} {cand.get('lastName')}): {len(notes)} notes → {sorted(actions) if actions else '(none)'}")
        time.sleep(0.1)

print(f"\n  All unique actions found: {sorted(all_actions)}")

# ─── Export: ALL pipeline candidates for these jobs ──────────────────────────

print("\n\n" + "=" * 70)
print("  EXPORT: All Pipeline/Response candidates for jobs 34637/34638/34639")
print("=" * 70)

all_candidates = []
for job_id in JOB_IDS:
    # Get job title
    job = client.get_job(job_id)
    job_title = job.get("title", f"Job {job_id}") if job else f"Job {job_id}"
    
    start = 0
    while True:
        url = f"{client.rest_url}search/JobSubmission"
        params = {
            "query": f"jobOrder.id:{job_id} AND isDeleted:0",
            "fields": "id,status,dateAdded,candidate(id,firstName,lastName,email,phone,occupation,source,status)",
            "count": 200,
            "start": start,
            "sort": "-dateAdded"
        }
        resp = requests.get(url, headers=client.get_headers(), params=params)
        data = resp.json()
        records = data.get("data", [])
        total = data.get("total", 0)
        
        if not records:
            break
        
        for sub in records:
            cand = sub.get("candidate", {})
            all_candidates.append({
                "candidate_id": cand.get("id", ""),
                "first_name": cand.get("firstName", ""),
                "last_name": cand.get("lastName", ""),
                "email": cand.get("email", ""),
                "phone": cand.get("phone", ""),
                "source": cand.get("source", ""),
                "occupation": cand.get("occupation", ""),
                "submission_status": sub.get("status", ""),
                "date_added": sub.get("dateAdded", ""),
                "job_id": job_id,
                "job_title": job_title
            })
        
        start += 200
        if start >= total:
            break
        time.sleep(0.1)
    
    job_count = len([c for c in all_candidates if c["job_id"] == job_id])
    print(f"  Job {job_id} ({job_title}): {job_count} candidates")

# Write CSV
timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
output_dir = os.path.join(os.path.dirname(__file__), '..', '..', 'exports')
os.makedirs(output_dir, exist_ok=True)
output_file = os.path.join(output_dir, f"all_pipeline_candidates_{timestamp}.csv")

fieldnames = ["candidate_id", "first_name", "last_name", "email", "phone", "source", 
              "occupation", "submission_status", "date_added", "job_id", "job_title"]
with open(output_file, 'w', newline='', encoding='utf-8') as f:
    writer = csv.DictWriter(f, fieldnames=fieldnames)
    writer.writeheader()
    writer.writerows(all_candidates)

print(f"\n  Total candidates: {len(all_candidates)}")
print(f"  📄 CSV saved to: {os.path.abspath(output_file)}")
print("=" * 70)
