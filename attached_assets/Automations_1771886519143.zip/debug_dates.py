#!/usr/bin/env python3
"""Debug: find where 2025 candidates are in the pagination."""
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), '..'))
import requests
from datetime import datetime
from integrations.bullhorn_client import BullhornClient
import logging; logging.disable(logging.CRITICAL)

client = BullhornClient()
client.connect()
url = f"{client.rest_url}search/Candidate"
jan1 = int(datetime(2025, 1, 1).timestamp() * 1000)
dec31 = int(datetime(2025, 12, 31, 23, 59, 59).timestamp() * 1000)

print("Finding where 2025 candidates are in -dateAdded pagination...", flush=True)
for offset in [0, 1000, 2000, 3000, 4000, 5000, 6000, 7000, 10000, 15000, 20000]:
    params = {"query": "isDeleted:0", "fields": "id,dateAdded", "count": 1, "start": offset, "sort": "-dateAdded"}
    resp = requests.get(url, headers=client.get_headers(), params=params, timeout=30)
    d = resp.json().get("data", [])
    if d:
        da = d[0]["dateAdded"]
        dt = datetime.fromtimestamp(da/1000)
        in2025 = jan1 <= da <= dec31
        print(f"  start={offset:>6}: date={dt.strftime('%Y-%m-%d')} in2025={in2025}", flush=True)
    else:
        print(f"  start={offset:>6}: EMPTY", flush=True)
print("Done!", flush=True)
