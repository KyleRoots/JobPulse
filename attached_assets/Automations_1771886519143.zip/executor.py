"""
Action Executor

Executes automation actions against the ATS.
"""

import logging
import time
from typing import Dict, List, Any, Optional
from datetime import datetime

from .models import Action, ActionResult, ExecutionStatus

logger = logging.getLogger("ActionExecutor")


class ActionExecutor:
    """
    Executes automation actions with error handling and logging.
    
    Supports:
    - Sequential action execution
    - Error handling with optional retry
    - Execution timing and logging
    """
    
    def __init__(self, ats_client):
        """Initialize with ATS client."""
        self.client = ats_client
        self._action_handlers = self._register_handlers()
    
    def _register_handlers(self) -> Dict[str, callable]:
        """Register action type handlers."""
        return {
            # Candidate actions
            "update_candidate": self._update_candidate,
            "change_candidate_status": self._change_candidate_status,
            "add_note": self._add_note,
            "send_email": self._send_email,
            
            # Submission actions
            "update_submission_status": self._update_submission_status,
            "create_submission": self._create_submission,
            
            # AI actions
            "screen_candidate": self._screen_candidate,
            "generate_text": self._generate_text,
            
            # Notification actions
            "notify_user": self._notify_user,
            "log_message": self._log_message,
        }
    
    def execute_actions(self, actions: List[Action], trigger_data: Dict) -> List[ActionResult]:
        """
        Execute a list of actions in order.
        
        Args:
            actions: List of actions to execute
            trigger_data: Data from the trigger (available to actions)
            
        Returns:
            List of ActionResult for each action
        """
        results = []
        
        # Sort by order
        sorted_actions = sorted(actions, key=lambda a: a.order)
        
        for action in sorted_actions:
            start_time = time.time()
            
            try:
                result = self._execute_single(action, trigger_data)
                duration_ms = int((time.time() - start_time) * 1000)
                
                results.append(ActionResult(
                    action_type=action.action_type,
                    success=True,
                    result=result,
                    duration_ms=duration_ms
                ))
                
                # Add result to trigger_data for subsequent actions
                trigger_data[f"_result_{action.action_type}"] = result
                
            except Exception as e:
                duration_ms = int((time.time() - start_time) * 1000)
                logger.error(f"Action {action.action_type} failed: {e}")
                
                results.append(ActionResult(
                    action_type=action.action_type,
                    success=False,
                    error=str(e),
                    duration_ms=duration_ms
                ))
        
        return results
    
    def _execute_single(self, action: Action, trigger_data: Dict) -> Dict:
        """Execute a single action."""
        handler = self._action_handlers.get(action.action_type)
        
        if not handler:
            raise ValueError(f"Unknown action type: {action.action_type}")
        
        # Merge trigger data into parameters for variable substitution
        params = self._substitute_variables(action.parameters, trigger_data)
        
        return handler(params, trigger_data)
    
    def _substitute_variables(self, params: Dict, trigger_data: Dict) -> Dict:
        """
        Substitute {{variable}} placeholders in parameters.
        
        Example:
            params = {"candidate_id": "{{trigger.candidate.id}}"}
            trigger_data = {"trigger": {"candidate": {"id": 123}}}
            Result: {"candidate_id": 123}
        """
        result = {}
        
        for key, value in params.items():
            if isinstance(value, str) and "{{" in value:
                # Extract variable path
                import re
                matches = re.findall(r'\{\{([^}]+)\}\}', value)
                
                for match in matches:
                    # Navigate the path
                    current = trigger_data
                    for part in match.split("."):
                        if isinstance(current, dict):
                            current = current.get(part)
                        else:
                            current = None
                            break
                    
                    # Replace in value
                    if current is not None:
                        if value == f"{{{{{match}}}}}":
                            # Full replacement (preserve type)
                            value = current
                        else:
                            # Partial replacement (string)
                            value = value.replace(f"{{{{{match}}}}}", str(current))
                
                result[key] = value
            elif isinstance(value, dict):
                result[key] = self._substitute_variables(value, trigger_data)
            else:
                result[key] = value
        
        return result
    
    # -------------------------------------------------------------------------
    # Action Handlers
    # -------------------------------------------------------------------------
    
    def _update_candidate(self, params: Dict, trigger_data: Dict) -> Dict:
        """Update candidate fields."""
        import requests
        
        candidate_id = params.get("candidate_id")
        updates = params.get("updates", {})
        
        url = f"{self.client.rest_url}entity/Candidate/{candidate_id}"
        response = requests.post(url, headers=self.client.get_headers(), json=updates)
        
        if response.status_code == 200:
            return {"success": True, "candidate_id": candidate_id}
        else:
            raise Exception(f"Update failed: {response.text}")
    
    def _change_candidate_status(self, params: Dict, trigger_data: Dict) -> Dict:
        """Change candidate status."""
        return self._update_candidate({
            "candidate_id": params.get("candidate_id"),
            "updates": {"status": params.get("status")}
        }, trigger_data)
    
    def _add_note(self, params: Dict, trigger_data: Dict) -> Dict:
        """Add note to candidate."""
        candidate_id = params.get("candidate_id")
        action = params.get("action", "Automation Note")
        comments = params.get("comments", "")
        
        result = self.client.create_note(candidate_id, {
            "action": action,
            "comments": comments
        })
        
        if result:
            return {"success": True, "note_id": result.get("changedEntityId")}
        else:
            raise Exception("Failed to create note")
    
    def _send_email(self, params: Dict, trigger_data: Dict) -> Dict:
        """
        Send email. 
        
        In production, this would integrate with:
        - Bullhorn's email API
        - SendGrid/AWS SES
        - SMTP
        """
        to = params.get("to")
        subject = params.get("subject")
        body = params.get("body")
        
        # Placeholder - log instead of actually sending
        logger.info(f"[EMAIL] To: {to}, Subject: {subject}")
        
        return {
            "success": True,
            "to": to,
            "subject": subject,
            "sent_at": datetime.now().isoformat()
        }
    
    def _update_submission_status(self, params: Dict, trigger_data: Dict) -> Dict:
        """Update job submission status."""
        import requests
        
        submission_id = params.get("submission_id")
        status = params.get("status")
        
        url = f"{self.client.rest_url}entity/JobSubmission/{submission_id}"
        response = requests.post(url, headers=self.client.get_headers(), 
                                json={"status": status})
        
        if response.status_code == 200:
            return {"success": True, "submission_id": submission_id, "new_status": status}
        else:
            raise Exception(f"Update failed: {response.text}")
    
    def _create_submission(self, params: Dict, trigger_data: Dict) -> Dict:
        """Create job submission."""
        result = self.client.create_job_submission({
            "candidate": {"id": params.get("candidate_id")},
            "jobOrder": {"id": params.get("job_id")},
            "status": params.get("status", "Submitted"),
            "dateWebResponse": int(datetime.now().timestamp() * 1000)
        })
        
        if result:
            return {"success": True, "submission_id": result.get("changedEntityId")}
        else:
            raise Exception("Failed to create submission")
    
    def _screen_candidate(self, params: Dict, trigger_data: Dict) -> Dict:
        """
        AI screening of candidate against job requirements.
        
        In production, this would:
        1. Get candidate details
        2. Get job requirements
        3. Call AI model to score fit
        """
        candidate_id = params.get("candidate_id")
        job_id = params.get("job_id")
        
        # Placeholder - would call AI model
        return {
            "candidate_id": candidate_id,
            "job_id": job_id,
            "score": 75,  # Placeholder score
            "recommendation": "Review",
            "reasoning": "Candidate meets basic requirements"
        }
    
    def _generate_text(self, params: Dict, trigger_data: Dict) -> Dict:
        """
        Generate text using AI.
        
        In production, this would call Claude/GPT.
        """
        prompt = params.get("prompt", "")
        
        # Placeholder
        return {
            "generated_text": f"[AI Generated Response for: {prompt[:50]}...]",
            "model": "opus"
        }
    
    def _notify_user(self, params: Dict, trigger_data: Dict) -> Dict:
        """Send notification to user (in-app, Slack, etc.)."""
        message = params.get("message")
        channel = params.get("channel", "in_app")
        
        logger.info(f"[NOTIFICATION] Channel: {channel}, Message: {message}")
        
        return {
            "success": True,
            "channel": channel,
            "sent_at": datetime.now().isoformat()
        }
    
    def _log_message(self, params: Dict, trigger_data: Dict) -> Dict:
        """Log a message (for debugging/auditing)."""
        message = params.get("message", "")
        level = params.get("level", "info")
        
        if level == "error":
            logger.error(message)
        elif level == "warning":
            logger.warning(message)
        else:
            logger.info(message)
        
        return {"logged": True, "level": level}
