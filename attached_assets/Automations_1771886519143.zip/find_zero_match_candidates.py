#!/usr/bin/env python3
"""
Zero Match Score Cleanup Script

Finds candidate records from the past 6 hours that have:
- Action Note: "AI Vetting - Not Recommended"
- Note content contains: "Highest Match Score: 0%"

These records may be incorrect data that needs cleanup in the ATS.

Usage:
  python3 find_zero_match_candidates.py --dry-run     # Preview candidates
  python3 find_zero_match_candidates.py --hours 12    # Look back 12 hours
  python3 find_zero_match_candidates.py --export      # Export to CSV
"""

import sys
import os
import requests
import logging
import argparse
import csv
from datetime import datetime, timedelta

# Add src to path
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from integrations.bullhorn_client import BullhornClient

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(message)s')
logger = logging.getLogger(__name__)

# Constants
TARGET_ACTION = "AI Vetting - Not Recommended"
TARGET_CONTENT = "Highest Match Score: 0%"


def search_notes_by_action(client: BullhornClient, action_type: str, hours_back: int = 6) -> list:
    """
    Search for notes with a specific action type added in the last N hours.
    
    Uses pagination to fetch ALL matching notes, not just the first batch.
    """
    # Calculate timestamp for N hours ago (Bullhorn uses milliseconds)
    cutoff_time = int((datetime.now() - timedelta(hours=hours_back)).timestamp() * 1000)
    
    url = f"{client.rest_url}search/Note"
    all_notes = []
    start = 0
    batch_size = 500
    
    logger.info(f"Searching for notes in last {hours_back} hours...")
    
    while True:
        params = {
            "query": f'dateAdded:[{cutoff_time} TO *]',
            "fields": "id,action,comments,dateAdded,personReference(id,firstName,lastName,email)",
            "count": batch_size,
            "start": start,
            "sort": "-dateAdded"
        }
        
        try:
            resp = requests.get(url, headers=client.get_headers(), params=params)
            
            if resp.status_code == 401:
                logger.info("Re-authenticating...")
                client.connect()
                resp = requests.get(url, headers=client.get_headers(), params=params)
            
            resp.raise_for_status()
            data = resp.json()
            batch = data.get("data", [])
            total = data.get("total", 0)
            
            if start == 0:
                logger.info(f"Total notes in time range: {total}")
            
            # Filter for target action type in this batch
            matching = [n for n in batch if n.get("action") == action_type]
            all_notes.extend(matching)
            
            logger.info(f"Fetched batch {start}-{start + len(batch)}, found {len(matching)} matching in batch ({len(all_notes)} total)")
            
            # Check if we've fetched all notes in time range
            start += len(batch)
            if len(batch) < batch_size or start >= total:
                break
                
        except Exception as e:
            logger.error(f"Search failed at offset {start}: {e}")
            break
    
    logger.info(f"Total notes with action '{action_type}': {len(all_notes)}")
    return all_notes


def filter_zero_match_notes(notes: list) -> list:
    """
    Filter notes to only include those with "Highest Match Score: 0%" in comments.
    """
    matching = []
    for note in notes:
        comments = note.get("comments", "") or ""
        if TARGET_CONTENT in comments:
            matching.append(note)
    
    logger.info(f"Filtered to {len(matching)} notes with '{TARGET_CONTENT}'")
    return matching


def get_candidate_from_note(client: BullhornClient, note: dict) -> dict:
    """
    Extract candidate info from the note's personReference.
    """
    person_ref = note.get("personReference", {}) or {}
    
    return {
        "note_id": note.get("id"),
        "candidate_id": person_ref.get("id"),
        "candidate_name": f"{person_ref.get('firstName', '')} {person_ref.get('lastName', '')}".strip(),
        "candidate_email": person_ref.get("email", "N/A"),
        "action": note.get("action"),
        "date_added": note.get("dateAdded"),
        "comments_preview": (note.get("comments", "") or "")[:200]
    }


def format_timestamp(ts_ms):
    """Convert Bullhorn millisecond timestamp to readable format."""
    if not ts_ms:
        return "Unknown"
    try:
        dt = datetime.fromtimestamp(ts_ms / 1000)
        return dt.strftime("%Y-%m-%d %H:%M:%S")
    except:
        return str(ts_ms)


def export_to_csv(candidates: list, filename: str):
    """Export candidate list to CSV for review."""
    if not candidates:
        logger.warning("No candidates to export")
        return
    
    with open(filename, 'w', newline='') as f:
        writer = csv.DictWriter(f, fieldnames=[
            'note_id', 'candidate_id', 'candidate_name', 'candidate_email', 
            'action', 'date_added', 'comments_preview'
        ])
        writer.writeheader()
        for c in candidates:
            c['date_added'] = format_timestamp(c.get('date_added'))
            writer.writerow(c)
    
    logger.info(f"Exported {len(candidates)} records to {filename}")


def delete_note(client: BullhornClient, note_id: int) -> bool:
    """Soft-delete a note by setting isDeleted=true."""
    url = f"{client.rest_url}entity/Note/{note_id}"
    payload = {"isDeleted": True}
    
    try:
        resp = requests.post(url, headers=client.get_headers(), json=payload)
        if resp.status_code == 401:
            client.connect()
            resp = requests.post(url, headers=client.get_headers(), json=payload)
        resp.raise_for_status()
        return True
    except Exception as e:
        logger.error(f"Failed to delete note {note_id}: {e}")
        return False


def main():
    parser = argparse.ArgumentParser(description="Find candidates with 0% match score notes")
    parser.add_argument("--dry-run", action="store_true", default=True, 
                        help="Preview candidates without taking action (default)")
    parser.add_argument("--delete", action="store_true", 
                        help="Delete the matching notes (use with caution!)")
    parser.add_argument("--hours", type=int, default=6, 
                        help="Hours to look back (default: 6)")
    parser.add_argument("--export", type=str, 
                        help="Export results to CSV file (e.g., --export results.csv)")
    args = parser.parse_args()
    
    print("\n" + "="*60)
    print("ZERO MATCH SCORE CANDIDATE FINDER")
    print("="*60)
    print(f"Looking for: Action = '{TARGET_ACTION}'")
    print(f"             Content contains: '{TARGET_CONTENT}'")
    print(f"             Time range: Last {args.hours} hours")
    print("="*60 + "\n")
    
    # Connect to Bullhorn
    logger.info("Connecting to Bullhorn...")
    client = BullhornClient()
    
    try:
        client.connect()
        if not client.rest_url:
            logger.error("Failed to connect to Bullhorn. Check credentials.")
            return
    except Exception as e:
        logger.error(f"Failed to connect to Bullhorn: {e}")
        return
    
    logger.info("Connected successfully")
    
    # Search for notes
    notes = search_notes_by_action(client, TARGET_ACTION, args.hours)
    
    if not notes:
        print("\n✓ No notes found with the target action in the specified time range.")
        return
    
    # Filter for zero match score
    filtered_notes = filter_zero_match_notes(notes)
    
    if not filtered_notes:
        print(f"\n✓ Found {len(notes)} notes with action '{TARGET_ACTION}'")
        print(f"  but NONE contained '{TARGET_CONTENT}'")
        return
    
    # Get candidate info
    candidates = []
    for note in filtered_notes:
        candidate = get_candidate_from_note(client, note)
        candidates.append(candidate)
    
    # Display results
    print("\n" + "="*60)
    print(f"FOUND {len(candidates)} MATCHING RECORDS")
    print("="*60 + "\n")
    
    for i, c in enumerate(candidates, 1):
        print(f"{i}. {c['candidate_name']} (ID: {c['candidate_id']})")
        print(f"   Email: {c['candidate_email']}")
        print(f"   Note ID: {c['note_id']}")
        print(f"   Date: {format_timestamp(c['date_added'])}")
        print(f"   Preview: {c['comments_preview'][:100]}...")
        print()
    
    # Export if requested
    if args.export:
        export_to_csv(candidates, args.export)
    
    # Delete if requested
    if args.delete:
        confirm = input(f"\n⚠️  Are you sure you want to delete {len(candidates)} notes? (yes/no): ")
        if confirm.lower() == 'yes':
            deleted = 0
            for c in candidates:
                if delete_note(client, c['note_id']):
                    deleted += 1
                    logger.info(f"Deleted note {c['note_id']}")
            print(f"\n✓ Deleted {deleted} of {len(candidates)} notes")
        else:
            print("Deletion cancelled.")
    else:
        print("\nDRY RUN - No changes made.")
        print(f"To export: python3 {__file__} --export results.csv")
        print(f"To delete: python3 {__file__} --delete")


if __name__ == "__main__":
    main()
