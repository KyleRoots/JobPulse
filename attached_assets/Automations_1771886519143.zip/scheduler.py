"""
Scheduler

Handles scheduled (cron-based) automation execution.
"""

import logging
import threading
import time
from typing import Dict, List, Optional, Callable
from datetime import datetime, timedelta
from dataclasses import dataclass

logger = logging.getLogger("Scheduler")


@dataclass
class ScheduledTask:
    """A scheduled automation task."""
    automation_id: str
    cron_expression: str
    timezone: str
    next_run: datetime
    callback: Callable


class Scheduler:
    """
    Simple scheduler for automation execution.
    
    In production, you'd use:
    - APScheduler
    - Celery Beat
    - Cloud scheduler (AWS EventBridge, Cloud Scheduler)
    """
    
    def __init__(self):
        self._tasks: Dict[str, ScheduledTask] = {}
        self._running = False
        self._thread: Optional[threading.Thread] = None
        self._check_interval = 60  # Check every minute
    
    def schedule(self, automation_id: str, cron_expression: str, 
                 callback: Callable, timezone: str = "America/New_York") -> bool:
        """
        Schedule an automation to run on a cron schedule.
        
        Args:
            automation_id: Unique ID for the automation
            cron_expression: Cron expression (minute hour day month weekday)
            callback: Function to call when triggered
            timezone: Timezone for the schedule
        """
        try:
            next_run = self._get_next_run(cron_expression)
            
            self._tasks[automation_id] = ScheduledTask(
                automation_id=automation_id,
                cron_expression=cron_expression,
                timezone=timezone,
                next_run=next_run,
                callback=callback
            )
            
            logger.info(f"Scheduled automation {automation_id}: next run at {next_run}")
            return True
            
        except Exception as e:
            logger.error(f"Failed to schedule {automation_id}: {e}")
            return False
    
    def unschedule(self, automation_id: str) -> bool:
        """Remove a scheduled automation."""
        if automation_id in self._tasks:
            del self._tasks[automation_id]
            logger.info(f"Unscheduled automation {automation_id}")
            return True
        return False
    
    def get_next_runs(self, count: int = 10) -> List[Dict]:
        """Get upcoming scheduled runs."""
        runs = []
        for task in self._tasks.values():
            runs.append({
                "automation_id": task.automation_id,
                "next_run": task.next_run.isoformat(),
                "cron": task.cron_expression
            })
        
        # Sort by next_run
        runs.sort(key=lambda x: x["next_run"])
        return runs[:count]
    
    def start(self):
        """Start the scheduler background thread."""
        if self._running:
            return
        
        self._running = True
        self._thread = threading.Thread(target=self._run_loop, daemon=True)
        self._thread.start()
        logger.info("Scheduler started")
    
    def stop(self):
        """Stop the scheduler."""
        self._running = False
        if self._thread:
            self._thread.join(timeout=5)
        logger.info("Scheduler stopped")
    
    def _run_loop(self):
        """Main scheduler loop."""
        while self._running:
            try:
                now = datetime.now()
                
                for task in list(self._tasks.values()):
                    if task.next_run <= now:
                        # Execute the callback
                        try:
                            task.callback(task.automation_id)
                        except Exception as e:
                            logger.error(f"Task {task.automation_id} failed: {e}")
                        
                        # Calculate next run
                        task.next_run = self._get_next_run(task.cron_expression)
                        logger.info(f"Task {task.automation_id} executed, next at {task.next_run}")
                
            except Exception as e:
                logger.error(f"Scheduler error: {e}")
            
            time.sleep(self._check_interval)
    
    def _get_next_run(self, cron_expression: str) -> datetime:
        """
        Calculate next run time from cron expression.
        
        Format: minute hour day month weekday
        Example: "0 9 * * 1" = Every Monday at 9:00 AM
        
        This is a simplified implementation. Production would use
        a proper cron parser like croniter.
        """
        parts = cron_expression.split()
        if len(parts) != 5:
            raise ValueError(f"Invalid cron expression: {cron_expression}")
        
        minute, hour, day, month, weekday = parts
        
        now = datetime.now()
        
        # Simple cases
        if minute.isdigit() and hour.isdigit():
            target_hour = int(hour)
            target_minute = int(minute)
            
            # Start with today at the target time
            next_run = now.replace(hour=target_hour, minute=target_minute, second=0, microsecond=0)
            
            # If time has passed today, move to tomorrow
            if next_run <= now:
                next_run += timedelta(days=1)
            
            # Handle weekday constraints
            if weekday != "*" and weekday.isdigit():
                target_weekday = int(weekday)  # 0=Monday, 6=Sunday
                
                # Find next occurrence of this weekday
                while next_run.weekday() != target_weekday:
                    next_run += timedelta(days=1)
            
            return next_run
        
        # Default: run in 1 hour
        return now + timedelta(hours=1)
    
    def run_now(self, automation_id: str) -> bool:
        """Manually trigger a scheduled automation immediately."""
        if automation_id in self._tasks:
            task = self._tasks[automation_id]
            try:
                task.callback(task.automation_id)
                return True
            except Exception as e:
                logger.error(f"Manual run failed for {automation_id}: {e}")
                return False
        return False
