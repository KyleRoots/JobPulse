#!/usr/bin/env python3
"""
Note Cleanup Automation - AI Vetting Notes
Finds and deletes notes with AI-related action types across candidate records.

Target action types:
- AI Vetting - Qualified
- AI Vetting - Not Recommended  
- AI Resume Summary
- AI Vetted - Accept
- AI Vetted - Reject

Usage:
  python3 cleanup_ai_vetting_notes.py --dry-run                    # Scan and preview
  python3 cleanup_ai_vetting_notes.py --dry-run --candidate-ids 123,456  # Check specific candidates
  python3 cleanup_ai_vetting_notes.py --execute                    # Delete the notes
"""

import sys
import os
import requests
import logging
import argparse

# Add src to path
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from integrations.bullhorn_client import BullhornClient

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(message)s')
logger = logging.getLogger(__name__)

# Action patterns to match for deletion
AI_ACTION_PATTERNS = [
    "AI Vetting",
    "AI Resume Summary", 
    "AI Vetted",
]


def is_ai_note(action: str) -> bool:
    """Check if note action matches any AI pattern."""
    if not action:
        return False
    for pattern in AI_ACTION_PATTERNS:
        if pattern in action:
            return True
    return False


def get_candidate_notes(client: BullhornClient, candidate_id: int) -> list:
    """Fetch all notes for a candidate via entity endpoint."""
    url = f"{client.rest_url}entity/Candidate/{candidate_id}/notes"
    params = {
        "fields": "id,action,comments,dateAdded,commentingPerson(id,firstName,lastName)",
        "count": 100
    }
    
    try:
        resp = requests.get(url, headers=client.get_headers(), params=params)
        if resp.status_code == 401:
            client.connect()
            resp = requests.get(url, headers=client.get_headers(), params=params)
        resp.raise_for_status()
        return resp.json().get("data", [])
    except Exception as e:
        return []


def get_candidate_info(client: BullhornClient, candidate_id: int) -> dict:
    """Fetch candidate name and email."""
    url = f"{client.rest_url}entity/Candidate/{candidate_id}"
    params = {"fields": "id,firstName,lastName,email"}
    try:
        resp = requests.get(url, headers=client.get_headers(), params=params)
        resp.raise_for_status()
        return resp.json().get("data", {})
    except:
        return {"firstName": "Unknown", "lastName": "", "email": "N/A"}


def get_recent_candidates(client: BullhornClient, count: int = 500) -> list:
    """Get recently modified candidates (most likely to have AI notes)."""
    url = f"{client.rest_url}search/Candidate"
    params = {
        "query": "id:[1 TO *]",
        "fields": "id",
        "count": count,
        "sort": "-dateLastModified"
    }
    
    try:
        resp = requests.get(url, headers=client.get_headers(), params=params)
        if resp.status_code == 401:
            client.connect()
            resp = requests.get(url, headers=client.get_headers(), params=params)
        resp.raise_for_status()
        return [c.get("id") for c in resp.json().get("data", [])]
    except Exception as e:
        logger.error(f"Failed to fetch candidates: {e}")
        return []


def delete_note(client: BullhornClient, note_id: int) -> bool:
    """Soft-delete a note by setting isDeleted=true."""
    url = f"{client.rest_url}entity/Note/{note_id}"
    payload = {"isDeleted": True}
    
    try:
        resp = requests.post(url, headers=client.get_headers(), json=payload)
        if resp.status_code == 401:
            client.connect()
            resp = requests.post(url, headers=client.get_headers(), json=payload)
        resp.raise_for_status()
        return True
    except Exception as e:
        logger.error(f"Failed to delete note {note_id}: {e}")
        return False


def main():
    parser = argparse.ArgumentParser(description="Cleanup AI Vetting notes from Bullhorn")
    parser.add_argument("--dry-run", action="store_true", help="Preview notes without deleting")
    parser.add_argument("--execute", action="store_true", help="Actually delete the notes")
    parser.add_argument("--candidate-ids", type=str, help="Comma-separated candidate IDs to check")
    parser.add_argument("--scan-count", type=int, default=200, help="Number of candidates to scan (default: 200)")
    
    args = parser.parse_args()
    
    if not args.dry_run and not args.execute:
        print("Error: Must specify --dry-run or --execute")
        parser.print_help()
        sys.exit(1)
    
    # Connect to Bullhorn
    logger.info("Connecting to Bullhorn...")
    client = BullhornClient()
    client.connect()
    logger.info("Connected!")
    
    # Determine which candidates to scan
    if args.candidate_ids:
        candidate_ids = [int(x.strip()) for x in args.candidate_ids.split(",")]
        logger.info(f"Checking {len(candidate_ids)} specific candidates...")
    else:
        logger.info(f"Fetching {args.scan_count} most recently modified candidates...")
        candidate_ids = get_recent_candidates(client, args.scan_count)
        logger.info(f"Got {len(candidate_ids)} candidates to scan")
    
    # Scan for AI notes
    ai_notes = []
    checked = 0
    
    for cid in candidate_ids:
        notes = get_candidate_notes(client, cid)
        for note in notes:
            if is_ai_note(note.get("action", "")):
                cand_info = get_candidate_info(client, cid)
                ai_notes.append({
                    "note_id": note.get("id"),
                    "action": note.get("action"),
                    "comments": note.get("comments", "")[:80],
                    "candidate_id": cid,
                    "candidate_name": f"{cand_info.get('firstName', '')} {cand_info.get('lastName', '')}",
                    "candidate_email": cand_info.get("email", "N/A")
                })
        checked += 1
        if checked % 50 == 0:
            logger.info(f"Scanned {checked}/{len(candidate_ids)} candidates, found {len(ai_notes)} AI notes so far...")
    
    # Display results
    print("\n" + "=" * 80)
    print(f"FOUND {len(ai_notes)} AI-RELATED NOTES")
    print("=" * 80 + "\n")
    
    if not ai_notes:
        print("No AI notes found in the scanned candidates.")
        return
    
    for i, note in enumerate(ai_notes, 1):
        print(f"{i}. Note ID: {note['note_id']}")
        print(f"   Action: {note['action']}")
        print(f"   Candidate: {note['candidate_name']} (ID: {note['candidate_id']})")
        print(f"   Email: {note['candidate_email']}")
        print(f"   Comments: {note['comments']}...")
        print()
    
    # Execute or dry-run
    if args.dry_run:
        print("=" * 80)
        print("DRY RUN COMPLETE - No notes were deleted.")
        print(f"To delete these {len(ai_notes)} notes, run with --execute")
        print("=" * 80)
    
    elif args.execute:
        print("=" * 80)
        print("EXECUTING DELETE...")
        print("=" * 80)
        
        deleted = 0
        failed = 0
        
        for note in ai_notes:
            note_id = note["note_id"]
            if delete_note(client, note_id):
                logger.info(f"Deleted note {note_id}")
                deleted += 1
            else:
                failed += 1
        
        print()
        print("=" * 80)
        print(f"DELETION COMPLETE: {deleted} deleted, {failed} failed")
        print("=" * 80)


if __name__ == "__main__":
    main()
