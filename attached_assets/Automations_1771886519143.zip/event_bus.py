"""
Event Bus

Handles real-time event routing for event-triggered automations.
"""

import logging
from typing import Dict, List, Callable, Optional
from dataclasses import dataclass
from datetime import datetime
from queue import Queue
import threading

logger = logging.getLogger("EventBus")


@dataclass
class Event:
    """An ATS event."""
    event_type: str       # e.g., "candidate.created", "submission.status_changed"
    entity_type: str      # e.g., "Candidate", "JobSubmission"
    entity_id: int
    data: Dict
    timestamp: str
    
    def to_dict(self) -> Dict:
        return {
            "event_type": self.event_type,
            "entity_type": self.entity_type,
            "entity_id": self.entity_id,
            "data": self.data,
            "timestamp": self.timestamp
        }


class EventBus:
    """
    Central event routing for real-time automation triggers.
    
    Event sources:
    - Webhooks from Bullhorn
    - Polling service for changes
    - Internal events from other automations
    """
    
    def __init__(self):
        self._subscribers: Dict[str, List[Callable]] = {}
        self._queue: Queue = Queue()
        self._running = False
        self._thread: Optional[threading.Thread] = None
    
    def subscribe(self, event_type: str, callback: Callable) -> str:
        """
        Subscribe to an event type.
        
        Args:
            event_type: Event type pattern (supports wildcards)
                       e.g., "candidate.*" or "submission.status_changed"
            callback: Function to call with (event) parameter
            
        Returns:
            Subscription ID
        """
        if event_type not in self._subscribers:
            self._subscribers[event_type] = []
        
        self._subscribers[event_type].append(callback)
        
        logger.info(f"Subscribed to {event_type}")
        return f"{event_type}:{len(self._subscribers[event_type])}"
    
    def unsubscribe(self, event_type: str, callback: Callable) -> bool:
        """Unsubscribe from an event type."""
        if event_type in self._subscribers:
            try:
                self._subscribers[event_type].remove(callback)
                return True
            except ValueError:
                pass
        return False
    
    def publish(self, event: Event):
        """
        Publish an event to all matching subscribers.
        
        Events are queued and processed asynchronously.
        """
        self._queue.put(event)
        logger.debug(f"Event queued: {event.event_type} for {event.entity_type}:{event.entity_id}")
    
    def publish_sync(self, event: Event) -> List[Dict]:
        """
        Publish an event and wait for all handlers to complete.
        Returns list of handler results.
        """
        results = []
        
        for pattern, callbacks in self._subscribers.items():
            if self._matches_pattern(pattern, event.event_type):
                for callback in callbacks:
                    try:
                        result = callback(event)
                        results.append({"pattern": pattern, "success": True, "result": result})
                    except Exception as e:
                        logger.error(f"Handler error for {pattern}: {e}")
                        results.append({"pattern": pattern, "success": False, "error": str(e)})
        
        return results
    
    def _matches_pattern(self, pattern: str, event_type: str) -> bool:
        """Check if event_type matches subscription pattern."""
        if pattern == "*":
            return True
        
        if pattern.endswith(".*"):
            prefix = pattern[:-2]
            return event_type.startswith(prefix + ".")
        
        return pattern == event_type
    
    def start(self):
        """Start the event processing thread."""
        if self._running:
            return
        
        self._running = True
        self._thread = threading.Thread(target=self._process_loop, daemon=True)
        self._thread.start()
        logger.info("EventBus started")
    
    def stop(self):
        """Stop the event processing thread."""
        self._running = False
        self._queue.put(None)  # Signal to stop
        if self._thread:
            self._thread.join(timeout=5)
        logger.info("EventBus stopped")
    
    def _process_loop(self):
        """Main event processing loop."""
        while self._running:
            try:
                event = self._queue.get(timeout=1)
                
                if event is None:
                    continue
                
                self._dispatch(event)
                
            except Exception:
                pass  # Queue timeout, continue
    
    def _dispatch(self, event: Event):
        """Dispatch event to all matching subscribers."""
        for pattern, callbacks in self._subscribers.items():
            if self._matches_pattern(pattern, event.event_type):
                for callback in callbacks:
                    try:
                        callback(event)
                    except Exception as e:
                        logger.error(f"Handler error for {pattern}: {e}")
    
    def get_subscriptions(self) -> Dict[str, int]:
        """Get count of subscriptions per event type."""
        return {k: len(v) for k, v in self._subscribers.items()}


# Common event types
class EventTypes:
    """Standard ATS event types."""
    
    # Candidate events
    CANDIDATE_CREATED = "candidate.created"
    CANDIDATE_UPDATED = "candidate.updated"
    CANDIDATE_STATUS_CHANGED = "candidate.status_changed"
    
    # Submission events
    SUBMISSION_CREATED = "submission.created"
    SUBMISSION_STATUS_CHANGED = "submission.status_changed"
    
    # Job events
    JOB_CREATED = "job.created"
    JOB_UPDATED = "job.updated"
    JOB_STATUS_CHANGED = "job.status_changed"
    
    # File events
    FILE_UPLOADED = "file.uploaded"
    
    # Note events
    NOTE_ADDED = "note.added"


def create_event(event_type: str, entity_type: str, entity_id: int, 
                data: Dict = None) -> Event:
    """Helper to create an event."""
    return Event(
        event_type=event_type,
        entity_type=entity_type,
        entity_id=entity_id,
        data=data or {},
        timestamp=datetime.now().isoformat()
    )
