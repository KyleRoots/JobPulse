#!/bin/bash
# Sales Rep Sync — wrapper script for launchd
# Runs fix_salesrep_header.py --sync and logs output

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
PROJECT_DIR="$(cd "$SCRIPT_DIR/../.." && pwd)"
LOG_DIR="$PROJECT_DIR/exports"
LOG_FILE="$LOG_DIR/salesrep_sync.log"

mkdir -p "$LOG_DIR"

echo "" >> "$LOG_FILE"
echo "========== $(date '+%Y-%m-%d %H:%M:%S') ==========" >> "$LOG_FILE"

cd "$PROJECT_DIR"
/usr/bin/python3 "$SCRIPT_DIR/fix_salesrep_header.py" --sync >> "$LOG_FILE" 2>&1

echo "Exit code: $?" >> "$LOG_FILE"
