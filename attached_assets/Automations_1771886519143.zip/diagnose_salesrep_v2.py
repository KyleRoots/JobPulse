#!/usr/bin/env python3
"""
Deeper diagnostic: Find the EXACT field that stores Sales Rep on ClientCorporation.
Fetches full metadata and the entity record with all available fields.
"""
import os, sys, json, requests
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', '..'))
from integrations.bullhorn_client import BullhornClient

COMPANY_ID = 32846

client = BullhornClient()
client.connect()
print("Connected.\n")

# ─── 1. Full metadata for ClientCorporation ──────────────────────────────────

print("=" * 70)
print("  ALL ClientCorporation fields from metadata")
print("=" * 70)

meta_url = f"{client.rest_url}meta/ClientCorporation"
params = {"fields": "*"}
resp = requests.get(meta_url, headers=client.get_headers(), params=params)
meta = resp.json()
fields = meta.get("fields", [])

print(f"\n  Total fields: {len(fields)}\n")

# Print ALL fields, highlighting those with "sales", "rep", or "owner"
for f in sorted(fields, key=lambda x: x.get("name", "")):
    name = f.get("name", "")
    label = f.get("label", "")
    ftype = f.get("type", "")
    data_type = f.get("dataType", "")
    assoc = f.get("associatedEntity", {})
    assoc_entity = assoc.get("entity", "") if assoc else ""
    
    # Highlight interesting fields
    is_interesting = any(kw in name.lower() or kw in label.lower() 
                        for kw in ["sales", "rep", "owner", "user", "person"])
    marker = " ★★★" if is_interesting else ""
    
    assoc_str = f" → {assoc_entity}" if assoc_entity else ""
    print(f"  {name:40s} label={label:30s} type={ftype:10s} dataType={data_type:15s}{assoc_str}{marker}")

# ─── 2. Fetch entity with basic fields ───────────────────────────────────────

print(f"\n\n{'=' * 70}")
print(f"  Company {COMPANY_ID} - fetching with basic fields")
print("=" * 70)

# Start with just ID and name
entity_url = f"{client.rest_url}entity/ClientCorporation/{COMPANY_ID}"

# Batch 1: basic fields
basic_fields = "id,name,status,phone,address"
resp = requests.get(entity_url, headers=client.get_headers(), params={"fields": basic_fields})
if resp.status_code == 200:
    data = resp.json().get("data", {})
    print(f"\n  Company: {data.get('name')} (ID: {data.get('id')})")
    print(f"  Status: {data.get('status')}")

# ─── 3. Try each sales/owner related field individually ──────────────────────

print(f"\n{'─' * 70}")
print("  Testing individual sales/rep/owner fields")
print("─" * 70)

# Collect field names that might be the sales rep
candidate_fields = [f.get("name") for f in fields 
                   if any(kw in f.get("name", "").lower() or kw in f.get("label", "").lower() 
                         for kw in ["sales", "rep", "owner", "assigned"])]

# Also add custom fields
candidate_fields += [f.get("name") for f in fields 
                    if f.get("name", "").startswith("custom")]

print(f"\n  Testing {len(candidate_fields)} candidate fields...\n")

for field_name in candidate_fields:
    try:
        resp = requests.get(entity_url, headers=client.get_headers(), params={"fields": f"id,{field_name}"})
        if resp.status_code == 200:
            data = resp.json().get("data", {})
            val = data.get(field_name)
            if val is not None and val != "" and val != 0 and val != {"total": 0, "data": []}:
                print(f"  ✅ {field_name}: {json.dumps(val) if isinstance(val, (dict, list)) else repr(val)}")
        else:
            pass  # Skip broken fields silently
    except:
        pass

# ─── 4. Try fetching ALL scalar fields at once ──────────────────────────────

print(f"\n{'─' * 70}")
print("  Batch-fetching all SCALAR fields")
print("─" * 70)

scalar_fields = [f.get("name") for f in fields if f.get("type") == "SCALAR"]
# Fetch in batches of 30
for i in range(0, len(scalar_fields), 30):
    batch = scalar_fields[i:i+30]
    fields_str = ",".join(["id"] + batch)
    try:
        resp = requests.get(entity_url, headers=client.get_headers(), params={"fields": fields_str})
        if resp.status_code == 200:
            data = resp.json().get("data", {})
            for key, val in data.items():
                if key != "id" and val is not None and val != "" and val != 0:
                    print(f"  {key}: {repr(val)[:100]}")
    except:
        pass

# ─── 5. Try TO_ONE association fields ────────────────────────────────────────

print(f"\n{'─' * 70}")
print("  Fetching TO_ONE association fields (with id)")
print("─" * 70)

to_one_fields = [f for f in fields if f.get("type") == "TO_ONE"]
for f in to_one_fields:
    name = f.get("name")
    label = f.get("label")
    assoc = f.get("associatedEntity", {}).get("entity", "")
    try:
        resp = requests.get(entity_url, headers=client.get_headers(), params={"fields": f"id,{name}"})
        if resp.status_code == 200:
            data = resp.json().get("data", {})
            val = data.get(name)
            if val and isinstance(val, dict) and val.get("id"):
                print(f"  ✅ {name} (label='{label}', entity={assoc}): ID={val.get('id')}")
    except:
        pass

print("\n" + "=" * 70)
