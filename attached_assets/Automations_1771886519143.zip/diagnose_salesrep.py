#!/usr/bin/env python3
"""
Diagnose the Sales Rep field issue on Bullhorn ClientCorporation records.

Inspects company 32846 (Fluid Power Support) to understand:
1. What the salesRep field contains (association vs text)
2. What custom fields exist that might be used in the header
3. How to resolve CorporateUser ID → Name

This is a READ-ONLY diagnostic — no data is modified.
"""

import os, sys, json, requests
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', '..'))
from integrations.bullhorn_client import BullhornClient

COMPANY_ID = 32846  # Fluid Power Support

def main():
    print("=" * 70)
    print("  Sales Rep Field Diagnostic")
    print("  Company: 32846 (Fluid Power Support)")
    print("=" * 70)
    
    client = BullhornClient()
    client.connect()
    print("Connected.\n")
    
    # ─── 1. Get entity metadata to understand field types ─────────────────
    
    print("─" * 70)
    print("  STEP 1: ClientCorporation entity metadata (field types)")
    print("─" * 70)
    
    meta_url = f"{client.rest_url}meta/ClientCorporation"
    params = {"fields": "*"}
    try:
        resp = requests.get(meta_url, headers=client.get_headers(), params=params)
        resp.raise_for_status()
        meta = resp.json()
        
        fields = meta.get("fields", [])
        
        # Find salesRep and related fields
        salesrep_fields = [f for f in fields if "salesrep" in f.get("name", "").lower() 
                          or "sales" in f.get("name", "").lower()
                          or "rep" in f.get("name", "").lower()]
        
        print(f"\n  Found {len(salesrep_fields)} sales/rep-related fields:\n")
        for f in salesrep_fields:
            print(f"    Field: {f.get('name')}")
            print(f"      Label: {f.get('label')}")
            print(f"      Type: {f.get('type')}")
            print(f"      DataType: {f.get('dataType')}")
            if f.get("associatedEntity"):
                print(f"      Associated Entity: {f.get('associatedEntity', {}).get('entity')}")
            if f.get("options"):
                print(f"      Options: {f.get('options')[:3]}...")
            print()
        
        # Also look for customText fields that might store the header value
        custom_fields = [f for f in fields if f.get("name", "").startswith("customText")]
        print(f"  Found {len(custom_fields)} customText fields")
        for f in custom_fields[:10]:
            print(f"    {f.get('name')}: label='{f.get('label')}' type={f.get('type')}")
        
    except Exception as e:
        print(f"  Metadata fetch failed: {e}")
    
    # ─── 2. Fetch the actual company record with ALL fields ───────────────
    
    print(f"\n{'─' * 70}")
    print(f"  STEP 2: Fetch company {COMPANY_ID} - full record")
    print("─" * 70)
    
    # Get with common fields + salesRep + customText fields
    entity_url = f"{client.rest_url}entity/ClientCorporation/{COMPANY_ID}"
    params = {
        "fields": "id,name,salesRep(id,firstName,lastName,name),status,customText1,customText2,customText3,customText4,customText5,customText6,customText7,customText8,customText9,customText10,customText11,customText12,customText13,customText14,customText15,customText16,customText17,customText18,customText19,customText20"
    }
    
    try:
        resp = requests.get(entity_url, headers=client.get_headers(), params=params)
        resp.raise_for_status()
        company = resp.json().get("data", {})
        
        print(f"\n  Company: {company.get('name')}")
        print(f"  ID: {company.get('id')}")
        print(f"  Status: {company.get('status')}")
        
        # Show salesRep field
        sales_rep = company.get("salesRep", {})
        print(f"\n  salesRep field:")
        print(f"    {json.dumps(sales_rep, indent=4)}")
        
        # Show all customText fields
        print(f"\n  customText fields (non-empty):")
        for key, val in company.items():
            if key.startswith("customText") and val:
                print(f"    {key}: {repr(val)}")
        
    except Exception as e:
        print(f"  Entity fetch failed: {e}")
    
    # ─── 3. Fetch with wildcard fields ────────────────────────────────────
    
    print(f"\n{'─' * 70}")
    print(f"  STEP 3: Fetch company with '*' to see ALL populated fields")
    print("─" * 70)
    
    params = {"fields": "id,name,salesRep,customObject1s,customObject2s,customObject3s,customObject4s,customObject5s"}
    try:
        resp = requests.get(entity_url, headers=client.get_headers(), params=params)
        resp.raise_for_status()
        data = resp.json().get("data", {})
        
        print(f"\n  salesRep value: {repr(data.get('salesRep'))}")
        
        # Check custom objects
        for key in ["customObject1s", "customObject2s", "customObject3s", "customObject4s", "customObject5s"]:
            val = data.get(key)
            if val and val != {"total": 0, "data": []}:
                print(f"  {key}: {json.dumps(val)}")
                
    except Exception as e:
        print(f"  Failed: {e}")
    
    # ─── 4. Look up CorporateUser ID 70 ──────────────────────────────────
    
    print(f"\n{'─' * 70}")
    print(f"  STEP 4: Resolve CorporateUser ID 70")
    print("─" * 70)
    
    user_url = f"{client.rest_url}entity/CorporateUser/70"
    params = {"fields": "id,firstName,lastName,name,email,username"}
    
    try:
        resp = requests.get(user_url, headers=client.get_headers(), params=params)
        resp.raise_for_status()
        user = resp.json().get("data", {})
        
        print(f"\n  CorporateUser ID 70:")
        print(f"    Name: {user.get('firstName')} {user.get('lastName')}")
        print(f"    Full name: {user.get('name')}")
        print(f"    Email: {user.get('email')}")
        print(f"    Username: {user.get('username')}")
        
    except Exception as e:
        print(f"  Lookup failed: {e}")
    
    # ─── 5. Check header configuration ────────────────────────────────────
    
    print(f"\n{'─' * 70}")
    print(f"  STEP 5: Checking entity layout/settings for header fields")
    print("─" * 70)
    
    # Try settings/entitlements to see header config
    settings_url = f"{client.rest_url}settings/entitlements"
    try:
        resp = requests.get(settings_url, headers=client.get_headers())
        resp.raise_for_status()
        print(f"  Settings response keys: {list(resp.json().keys())[:10]}")
    except Exception as e:
        print(f"  Settings fetch failed: {e}")
    
    # Try fetching with all integer/salesRep fields to find the header source
    entity_url2 = f"{client.rest_url}entity/ClientCorporation/{COMPANY_ID}"
    params = {
        "fields": "id,name,salesRep,customInt1,customInt2,customInt3,customInt4,customInt5,customInt6,customInt7,customInt8,customInt9,customInt10"
    }
    try:
        resp = requests.get(entity_url2, headers=client.get_headers(), params=params)
        resp.raise_for_status()
        data = resp.json().get("data", {})
        
        print(f"\n  salesRep: {repr(data.get('salesRep'))}")
        for key in sorted(data.keys()):
            if key.startswith("customInt") and data[key]:
                print(f"  {key}: {repr(data[key])}")
                
    except Exception as e:
        print(f"  Failed: {e}")
    
    # ─── 6. Test update approach ──────────────────────────────────────────
    
    print(f"\n{'─' * 70}")
    print(f"  STEP 6: Summary & Recommendation")
    print("─" * 70)
    
    print("""
    The header "Sales Rep" field likely shows:
    - Option A: The raw salesRep association ID (70) because the header 
      card isn't resolving the TO-ONE association to display the name
    - Option B: A separate text/int field that stores "70" as a string
    
    If Option A: The salesRep association is already correct (points to 
      CorporateUser 70 = Kaniz Abedin). This is a Bullhorn UI/display 
      behavior we can't change via API.
    
    If Option B: We can update that field with the resolved name.
    
    Looking at the data above to determine which case applies...
    """)
    
    print("=" * 70)


if __name__ == "__main__":
    main()
