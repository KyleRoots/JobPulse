"""
Automation Models

Data models for Scout Automation: Automation definitions, triggers,
actions, and execution logs.
"""

import json
import uuid
from typing import Dict, List, Optional, Any, Union
from dataclasses import dataclass, field, asdict
from datetime import datetime
from enum import Enum


class TriggerType(Enum):
    """Types of automation triggers."""
    EVENT = "event"       # Real-time ATS events (webhook/polling)
    SCHEDULE = "schedule"  # Cron-based scheduled execution
    MANUAL = "manual"     # On-demand via chat


class AutomationStatus(Enum):
    """Automation lifecycle states."""
    DRAFT = "draft"       # Being built, not active
    ACTIVE = "active"     # Running
    PAUSED = "paused"     # Temporarily stopped
    DISABLED = "disabled" # Permanently stopped


class ExecutionStatus(Enum):
    """Execution run states."""
    PENDING = "pending"
    RUNNING = "running"
    SUCCESS = "success"
    PARTIAL = "partial"   # Some actions succeeded
    FAILED = "failed"


@dataclass
class Condition:
    """Condition for filtering when automation should run."""
    field: str           # e.g., "candidate.status"
    operator: str        # "equals", "contains", "greater_than", "in", etc.
    value: Any           # The value to compare against
    
    def evaluate(self, data: Dict) -> bool:
        """Evaluate this condition against data."""
        # Navigate nested fields (e.g., "candidate.status")
        current = data
        for part in self.field.split("."):
            if isinstance(current, dict):
                current = current.get(part)
            else:
                return False
        
        if self.operator == "equals":
            return current == self.value
        elif self.operator == "not_equals":
            return current != self.value
        elif self.operator == "contains":
            return self.value in str(current) if current else False
        elif self.operator == "greater_than":
            return float(current) > float(self.value) if current else False
        elif self.operator == "less_than":
            return float(current) < float(self.value) if current else False
        elif self.operator == "in":
            return current in self.value if isinstance(self.value, list) else False
        elif self.operator == "exists":
            return current is not None
        else:
            return False
    
    def to_dict(self) -> Dict:
        return asdict(self)


@dataclass
class Action:
    """Single action to execute in an automation."""
    action_type: str     # e.g., "update_candidate", "send_email", "add_note"
    parameters: Dict     # Action-specific parameters
    order: int = 0       # Execution order (for sequential actions)
    
    def to_dict(self) -> Dict:
        return asdict(self)


@dataclass
class TriggerConfig:
    """Configuration for automation triggers."""
    trigger_type: TriggerType
    
    # For EVENT triggers
    event_type: Optional[str] = None  # e.g., "candidate.created", "submission.status_changed"
    entity_type: Optional[str] = None  # e.g., "Candidate", "JobSubmission"
    
    # For SCHEDULE triggers
    cron_expression: Optional[str] = None  # e.g., "0 9 * * 1" (every Monday 9am)
    timezone: str = "America/New_York"
    
    def to_dict(self) -> Dict:
        result = {
            "trigger_type": self.trigger_type.value,
            "timezone": self.timezone
        }
        if self.event_type:
            result["event_type"] = self.event_type
        if self.entity_type:
            result["entity_type"] = self.entity_type
        if self.cron_expression:
            result["cron_expression"] = self.cron_expression
        return result


@dataclass
class Automation:
    """Complete automation definition."""
    id: str
    name: str
    description: str
    owner_id: str
    
    # Trigger configuration
    trigger: TriggerConfig
    
    # Conditions (all must pass for automation to run)
    conditions: List[Condition] = field(default_factory=list)
    
    # Actions to execute (in order)
    actions: List[Action] = field(default_factory=list)
    
    # State
    status: AutomationStatus = AutomationStatus.DRAFT
    created_at: str = field(default_factory=lambda: datetime.now().isoformat())
    updated_at: str = field(default_factory=lambda: datetime.now().isoformat())
    last_run: Optional[str] = None
    run_count: int = 0
    error_count: int = 0
    
    def should_run(self, trigger_data: Dict) -> bool:
        """Check if automation should run given trigger data."""
        if self.status != AutomationStatus.ACTIVE:
            return False
        
        # All conditions must pass
        return all(cond.evaluate(trigger_data) for cond in self.conditions)
    
    def to_dict(self) -> Dict:
        return {
            "id": self.id,
            "name": self.name,
            "description": self.description,
            "owner_id": self.owner_id,
            "trigger": self.trigger.to_dict(),
            "conditions": [c.to_dict() for c in self.conditions],
            "actions": [a.to_dict() for a in self.actions],
            "status": self.status.value,
            "created_at": self.created_at,
            "updated_at": self.updated_at,
            "last_run": self.last_run,
            "run_count": self.run_count,
            "error_count": self.error_count
        }
    
    @classmethod
    def from_dict(cls, data: Dict) -> 'Automation':
        """Create Automation from dictionary."""
        trigger_data = data.get("trigger", {})
        trigger = TriggerConfig(
            trigger_type=TriggerType(trigger_data.get("trigger_type", "manual")),
            event_type=trigger_data.get("event_type"),
            entity_type=trigger_data.get("entity_type"),
            cron_expression=trigger_data.get("cron_expression"),
            timezone=trigger_data.get("timezone", "America/New_York")
        )
        
        conditions = [
            Condition(**c) for c in data.get("conditions", [])
        ]
        
        actions = [
            Action(**a) for a in data.get("actions", [])
        ]
        
        return cls(
            id=data.get("id", str(uuid.uuid4())),
            name=data.get("name", "Untitled Automation"),
            description=data.get("description", ""),
            owner_id=data.get("owner_id", "unknown"),
            trigger=trigger,
            conditions=conditions,
            actions=actions,
            status=AutomationStatus(data.get("status", "draft")),
            created_at=data.get("created_at", datetime.now().isoformat()),
            updated_at=data.get("updated_at", datetime.now().isoformat()),
            last_run=data.get("last_run"),
            run_count=data.get("run_count", 0),
            error_count=data.get("error_count", 0)
        )


@dataclass
class ActionResult:
    """Result of executing a single action."""
    action_type: str
    success: bool
    result: Optional[Dict] = None
    error: Optional[str] = None
    duration_ms: int = 0
    
    def to_dict(self) -> Dict:
        return asdict(self)


@dataclass
class ExecutionLog:
    """Log of a single automation execution."""
    id: str
    automation_id: str
    automation_name: str
    triggered_at: str
    trigger_data: Dict
    
    # Execution details
    actions_executed: List[ActionResult] = field(default_factory=list)
    status: ExecutionStatus = ExecutionStatus.PENDING
    duration_ms: int = 0
    error: Optional[str] = None
    
    def to_dict(self) -> Dict:
        return {
            "id": self.id,
            "automation_id": self.automation_id,
            "automation_name": self.automation_name,
            "triggered_at": self.triggered_at,
            "trigger_data": self.trigger_data,
            "actions_executed": [a.to_dict() for a in self.actions_executed],
            "status": self.status.value,
            "duration_ms": self.duration_ms,
            "error": self.error
        }


class AutomationStorage:
    """
    Simple file-based storage for automations.
    In production, this would be a database.
    """
    
    def __init__(self, storage_path: str = "automations.json"):
        self.storage_path = storage_path
        self._automations: Dict[str, Automation] = {}
        self._load()
    
    def _load(self):
        """Load automations from file."""
        try:
            with open(self.storage_path, 'r') as f:
                data = json.load(f)
                for item in data.get("automations", []):
                    auto = Automation.from_dict(item)
                    self._automations[auto.id] = auto
        except FileNotFoundError:
            self._automations = {}
    
    def _save(self):
        """Save automations to file."""
        data = {
            "automations": [a.to_dict() for a in self._automations.values()]
        }
        with open(self.storage_path, 'w') as f:
            json.dump(data, f, indent=2)
    
    def create(self, automation: Automation) -> Automation:
        """Create a new automation."""
        if not automation.id:
            automation.id = str(uuid.uuid4())
        self._automations[automation.id] = automation
        self._save()
        return automation
    
    def get(self, automation_id: str) -> Optional[Automation]:
        """Get automation by ID."""
        return self._automations.get(automation_id)
    
    def list_all(self) -> List[Automation]:
        """List all automations."""
        return list(self._automations.values())
    
    def list_active(self) -> List[Automation]:
        """List active automations."""
        return [a for a in self._automations.values() 
                if a.status == AutomationStatus.ACTIVE]
    
    def update(self, automation: Automation) -> Automation:
        """Update an automation."""
        automation.updated_at = datetime.now().isoformat()
        self._automations[automation.id] = automation
        self._save()
        return automation
    
    def delete(self, automation_id: str) -> bool:
        """Delete an automation."""
        if automation_id in self._automations:
            del self._automations[automation_id]
            self._save()
            return True
        return False
