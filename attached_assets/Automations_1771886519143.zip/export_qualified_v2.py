#!/usr/bin/env python3
"""
Scout Genius - Export Qualified Candidates (v2)

Uses Bullhorn's QUERY API (not Search API) to find notes with custom action values.
The search/Lucene API doesn't index custom dropdown values, but the query API does.

Searches for candidates with notes having actions:
  - 'Scout Screen - Qualified'
  - 'AI Vetting - Qualified'  
  - 'AI Vetting - Recommended'

Filtered to jobs: 34637, 34638, 34639

Usage:
    python3 export_qualified_v2.py
"""

import os, sys, csv, time, requests, logging
from datetime import datetime

sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', '..'))
from integrations.bullhorn_client import BullhornClient

logging.basicConfig(level=logging.INFO, format='%(asctime)s [%(levelname)s] %(message)s', datefmt='%H:%M:%S')
logger = logging.getLogger("ExportQualifiedV2")

# ─── Configuration ───────────────────────────────────────────────────────────

JOB_IDS = [34637, 34638, 34639]

QUALIFYING_ACTIONS = [
    "Scout Screen - Qualified",
    "AI Vetting - Qualified",
    "AI Vetting - Recommended",
]

API_DELAY = 0.15
BATCH_SIZE = 200


def query_notes_by_action(client, action_text, count=500, start=0):
    """
    Use Bullhorn QUERY API (not search) to find notes with a specific action value.
    The query API uses SQL-like WHERE clauses and reads from DB, not Lucene index.
    """
    url = f"{client.rest_url}query/Note"
    params = {
        "where": f"action='{action_text}' AND isDeleted=false",
        "fields": "id,action,dateAdded,personReference(id,firstName,lastName)",
        "count": count,
        "start": start,
        "orderBy": "-dateAdded"
    }
    
    try:
        resp = requests.get(url, headers=client.get_headers(), params=params)
        resp.raise_for_status()
        data = resp.json()
        return data.get("data", []), data.get("total", 0)
    except Exception as e:
        logger.error(f"Query notes failed for action '{action_text}': {e}")
        # Try alternate field
        return [], 0


def get_note_candidates(client, note_id):
    """Get the candidate(s) associated with a note using entity associations."""
    url = f"{client.rest_url}entity/Note/{note_id}"
    params = {
        "fields": "id,action,dateAdded,candidates,personReference(id,firstName,lastName)"
    }
    try:
        resp = requests.get(url, headers=client.get_headers(), params=params)
        resp.raise_for_status()
        return resp.json().get("data", {})
    except Exception as e:
        logger.warning(f"Failed to get note {note_id} details: {e}")
        return {}


def get_candidate_details(client, candidate_id):
    """Fetch candidate details by ID."""
    url = f"{client.rest_url}entity/Candidate/{candidate_id}"
    params = {
        "fields": "id,firstName,lastName,email,phone,occupation,source,status"
    }
    try:
        resp = requests.get(url, headers=client.get_headers(), params=params)
        resp.raise_for_status()
        return resp.json().get("data", {})
    except Exception as e:
        logger.warning(f"Failed to get candidate {candidate_id}: {e}")
        return {}


def get_candidate_job_submissions(client, candidate_id):
    """Get job submissions for a candidate to see which jobs they're associated with."""
    url = f"{client.rest_url}query/JobSubmission"
    params = {
        "where": f"candidate.id={candidate_id} AND isDeleted=false",
        "fields": "id,jobOrder(id,title),status,dateAdded",
        "count": 50
    }
    try:
        resp = requests.get(url, headers=client.get_headers(), params=params)
        resp.raise_for_status()
        return resp.json().get("data", [])
    except Exception as e:
        logger.warning(f"Failed to get submissions for candidate {candidate_id}: {e}")
        return []


def get_all_job_submissions_for_job(client, job_id):
    """Get ALL candidate IDs submitted to a specific job using query API."""
    all_candidate_ids = set()
    start = 0
    
    while True:
        url = f"{client.rest_url}query/JobSubmission"
        params = {
            "where": f"jobOrder.id={job_id} AND isDeleted=false",
            "fields": "id,candidate(id)",
            "count": BATCH_SIZE,
            "start": start
        }
        try:
            resp = requests.get(url, headers=client.get_headers(), params=params)
            resp.raise_for_status()
            data = resp.json()
            records = data.get("data", [])
            total = data.get("total", 0)
            
            if not records:
                break
            
            for r in records:
                cand = r.get("candidate", {})
                if cand and cand.get("id"):
                    all_candidate_ids.add(cand["id"])
            
            start += BATCH_SIZE
            if start >= total:
                break
            time.sleep(API_DELAY)
        except Exception as e:
            logger.error(f"Failed to fetch submissions for job {job_id}: {e}")
            break
    
    return all_candidate_ids


def get_candidate_notes_via_query(client, candidate_id):
    """Use query API to get notes for a specific candidate."""
    url = f"{client.rest_url}query/Note"
    params = {
        "where": f"personReference.id={candidate_id} AND isDeleted=false",
        "fields": "id,action,dateAdded,comments",
        "count": 100,
        "orderBy": "-dateAdded"
    }
    try:
        resp = requests.get(url, headers=client.get_headers(), params=params)
        resp.raise_for_status()
        return resp.json().get("data", [])
    except Exception as e:
        logger.warning(f"Query notes for candidate {candidate_id} failed: {e}")
        return []


def main():
    print("=" * 70)
    print("  Scout Genius - Export Qualified Candidates (v2)")
    print("  Using Query API for custom note actions")
    print("=" * 70)
    print()
    
    client = BullhornClient()
    client.connect()
    logger.info("Connected to Bullhorn.\n")
    
    # ─── Step 1: Global search for qualifying notes using QUERY API ───────
    
    print("─" * 70)
    print("  STEP 1: Global search for qualifying note actions (Query API)")
    print("─" * 70)
    
    all_qualifying_note_ids = []
    all_qualifying_person_ids = set()
    
    for action in QUALIFYING_ACTIONS:
        notes, total = query_notes_by_action(client, action)
        print(f"\n  '{action}': {total} notes found")
        
        if total > 0:
            # Fetch all pages if more than initial count
            all_notes_for_action = list(notes)
            start = len(notes)
            while start < total:
                more_notes, _ = query_notes_by_action(client, action, count=BATCH_SIZE, start=start)
                if not more_notes:
                    break
                all_notes_for_action.extend(more_notes)
                start += BATCH_SIZE
                time.sleep(API_DELAY)
            
            for n in all_notes_for_action:
                all_qualifying_note_ids.append(n)
                person = n.get("personReference", {})
                if person and person.get("id"):
                    all_qualifying_person_ids.add(person["id"])
            
            # Show first few
            for n in notes[:5]:
                person = n.get("personReference", {})
                pname = f"{person.get('firstName', '')} {person.get('lastName', '')}" if person else "Unknown"
                print(f"    Note {n['id']}: {pname} (Person ID: {person.get('id', '?')})")
        
        time.sleep(API_DELAY)
    
    print(f"\n  Total qualifying notes: {len(all_qualifying_note_ids)}")
    print(f"  Unique person IDs with qualifying notes: {len(all_qualifying_person_ids)}")
    
    # ─── Step 2: Get candidate IDs for the target jobs ────────────────────
    
    print(f"\n{'─' * 70}")
    print("  STEP 2: Get candidate IDs for target jobs")
    print("─" * 70)
    
    job_titles = {}
    job_candidate_ids = {}
    all_job_candidate_ids = set()
    
    for job_id in JOB_IDS:
        job = client.get_job(job_id)
        job_titles[job_id] = job.get("title", f"Job {job_id}") if job else f"Job {job_id}"
        
        cand_ids = get_all_job_submissions_for_job(client, job_id)
        job_candidate_ids[job_id] = cand_ids
        all_job_candidate_ids.update(cand_ids)
        
        print(f"  Job {job_id} ({job_titles[job_id]}): {len(cand_ids)} candidates")
        time.sleep(API_DELAY)
    
    # ─── Step 3: Cross-reference ──────────────────────────────────────────
    
    print(f"\n{'─' * 70}")
    print("  STEP 3: Cross-reference qualifying notes with target jobs")
    print("─" * 70)
    
    # Find overlap between qualifying person IDs and job candidate IDs
    qualified_on_target_jobs = all_qualifying_person_ids.intersection(all_job_candidate_ids)
    print(f"\n  Candidates with qualifying notes AND on target jobs: {len(qualified_on_target_jobs)}")
    
    # ─── Step 4: Build export data ────────────────────────────────────────
    
    qualified_candidates = []
    
    if qualified_on_target_jobs:
        print(f"\n  Fetching details for {len(qualified_on_target_jobs)} qualified candidates...")
        
        for i, cand_id in enumerate(qualified_on_target_jobs):
            # Get candidate details
            cand = get_candidate_details(client, cand_id)
            time.sleep(API_DELAY)
            
            # Get their qualifying notes
            notes = get_candidate_notes_via_query(client, cand_id)
            qualifying_notes = [n for n in notes if n.get("action", "").strip() in QUALIFYING_ACTIONS]
            actions_found = list(set(n.get("action", "").strip() for n in qualifying_notes))
            time.sleep(API_DELAY)
            
            # Find which target jobs they're on
            for job_id in JOB_IDS:
                if cand_id in job_candidate_ids[job_id]:
                    for action in actions_found:
                        qualified_candidates.append({
                            "candidate_id": cand_id,
                            "first_name": cand.get("firstName", ""),
                            "last_name": cand.get("lastName", ""),
                            "email": cand.get("email", ""),
                            "phone": cand.get("phone", ""),
                            "occupation": cand.get("occupation", ""),
                            "job_id": job_id,
                            "job_title": job_titles[job_id],
                            "note_action": action
                        })
            
            logger.info(f"  [{i+1}/{len(qualified_on_target_jobs)}] {cand.get('firstName', '')} {cand.get('lastName', '')} — {', '.join(actions_found)}")
    
    # ─── Step 5: Also try alternative — scan per-candidate notes via query ──
    
    if not qualified_candidates:
        print(f"\n{'─' * 70}")
        print("  STEP 5: Alternative scan — checking candidate notes via query API")
        print("─" * 70)
        print(f"\n  Scanning {len(all_job_candidate_ids)} unique candidates across all 3 jobs...")
        print("  (This may take a while)")
        
        scanned = 0
        found = 0
        
        for cand_id in all_job_candidate_ids:
            notes = get_candidate_notes_via_query(client, cand_id)
            time.sleep(API_DELAY)
            
            qualifying_notes = [n for n in notes if n.get("action", "").strip() in QUALIFYING_ACTIONS]
            
            if qualifying_notes:
                found += 1
                cand = get_candidate_details(client, cand_id)
                actions_found = list(set(n.get("action", "").strip() for n in qualifying_notes))
                time.sleep(API_DELAY)
                
                for job_id in JOB_IDS:
                    if cand_id in job_candidate_ids[job_id]:
                        for action in actions_found:
                            qualified_candidates.append({
                                "candidate_id": cand_id,
                                "first_name": cand.get("firstName", ""),
                                "last_name": cand.get("lastName", ""),
                                "email": cand.get("email", ""),
                                "phone": cand.get("phone", ""),
                                "occupation": cand.get("occupation", ""),
                                "job_id": job_id,
                                "job_title": job_titles[job_id],
                                "note_action": action
                            })
                
                logger.info(f"  ✅ [{found}] {cand.get('firstName', '')} {cand.get('lastName', '')} (ID: {cand_id}) — {', '.join(actions_found)}")
            
            scanned += 1
            if scanned % 100 == 0:
                logger.info(f"  Scanned {scanned}/{len(all_job_candidate_ids)} candidates... ({found} qualified)")
    
    # ─── Export to CSV ────────────────────────────────────────────────────
    
    print(f"\n{'=' * 70}")
    print("  EXPORT RESULTS")
    print("=" * 70)
    
    if qualified_candidates:
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        output_dir = os.path.join(os.path.dirname(__file__), '..', '..', 'exports')
        os.makedirs(output_dir, exist_ok=True)
        output_file = os.path.join(output_dir, f"qualified_candidates_{timestamp}.csv")
        
        fieldnames = ["candidate_id", "first_name", "last_name", "email", "phone",
                      "occupation", "job_id", "job_title", "note_action"]
        
        with open(output_file, 'w', newline='', encoding='utf-8') as f:
            writer = csv.DictWriter(f, fieldnames=fieldnames)
            writer.writeheader()
            writer.writerows(qualified_candidates)
        
        unique_ids = set(c["candidate_id"] for c in qualified_candidates)
        print(f"  Total rows: {len(qualified_candidates)}")
        print(f"  Unique candidates: {len(unique_ids)}")
        
        for job_id in JOB_IDS:
            jcount = len([c for c in qualified_candidates if c["job_id"] == job_id])
            print(f"  Job {job_id} ({job_titles[job_id]}): {jcount}")
        
        for action in QUALIFYING_ACTIONS:
            acount = len([c for c in qualified_candidates if c["note_action"] == action])
            if acount > 0:
                print(f"  {action}: {acount}")
        
        print(f"\n  📄 CSV saved to: {os.path.abspath(output_file)}")
    else:
        print("  ⚠️  No qualified candidates found even with Query API.")
        print()
        print("  Possible explanations:")
        print("  1. The vetting notes may reference these candidates via a")
        print("     different association (jobOrder, not personReference)")
        print("  2. The notes may exist but under different candidate IDs")
        print("  3. The vetting process may not have been run on these specific jobs yet")
        print()
        print("  Recommendation: Export all pipeline candidates and filter manually")
        print(f"  (Already exported: exports/all_pipeline_candidates_*.csv)")
    
    print("=" * 70)


if __name__ == "__main__":
    main()
