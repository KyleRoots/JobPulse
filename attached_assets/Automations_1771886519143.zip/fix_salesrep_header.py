#!/usr/bin/env python3
"""
Fix Sales Rep Header: Populate customText6 with resolved CorporateUser names

The ClientCorporation.customText3 field (labeled "Sales Rep") stores
CorporateUser IDs as text (e.g., "70"). The Edit tab resolves this via
an optionsType lookup, but the header displays the raw ID.

Solution: Write the resolved name into customText6, which is configured
in the View Layout header. customText3 remains untouched.

Usage:
  python3 fix_salesrep_header.py --dry-run          # Preview changes (default)
  python3 fix_salesrep_header.py --test-single 32846 # Fix one company as proof
  python3 fix_salesrep_header.py --execute           # Fix ALL affected companies
  python3 fix_salesrep_header.py --sync              # Sync mode: fix only mismatched records
"""

import argparse
import csv
import json
import logging
import os
import re
import sys
import time
from datetime import datetime

import requests

sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', '..'))
from integrations.bullhorn_client import BullhornClient

logging.basicConfig(level=logging.INFO, format='%(levelname)s:%(name)s:%(message)s')
log = logging.getLogger("FixSalesRep")

# ─── Config ──────────────────────────────────────────────────────────────────
SOURCE_FIELD = "customText3"   # Stores CorporateUser ID (Edit tab)
DISPLAY_FIELD = "customText6"  # Stores resolved name (Header)
# ─────────────────────────────────────────────────────────────────────────────


def safe_str(val):
    """Bullhorn sometimes returns text fields as lists. Normalize to string."""
    if val is None:
        return ""
    if isinstance(val, list):
        return val[0].strip() if val else ""
    return str(val).strip()
# ─────────────────────────────────────────────────────────────────────────────

_user_cache = {}


def resolve_user(client, user_id):
    """Look up CorporateUser by ID, return 'FirstName LastName' or None."""
    if user_id in _user_cache:
        return _user_cache[user_id]

    try:
        url = f"{client.rest_url}entity/CorporateUser/{user_id}"
        params = {"fields": "id,firstName,lastName,name"}
        resp = requests.get(url, headers=client.get_headers(), params=params)
        resp.raise_for_status()
        user = resp.json().get("data", {})

        first = (user.get("firstName") or "").strip()
        last = (user.get("lastName") or "").strip()
        if first and last:
            full_name = f"{first} {last}"
        elif user.get("name"):
            full_name = user["name"].strip()
        else:
            full_name = None

        _user_cache[user_id] = full_name
        return full_name
    except Exception as e:
        log.warning(f"Failed to resolve CorporateUser {user_id}: {e}")
        _user_cache[user_id] = None
        return None


def is_numeric_id(value):
    """Check if a string looks like a numeric CorporateUser ID."""
    if not value:
        return False
    return bool(re.match(r'^\d+$', value.strip()))


def fetch_companies(client, single_id=None, sync_only=False):
    """
    Fetch companies that need fixing.
    Returns list of (company_id, company_name, source_id, current_display).

    If sync_only=True, only return records where customText6 doesn't match
    the resolved name from customText3.
    """
    results = []
    fields = f"id,name,{SOURCE_FIELD},{DISPLAY_FIELD}"

    if single_id:
        url = f"{client.rest_url}entity/ClientCorporation/{single_id}"
        try:
            resp = requests.get(url, headers=client.get_headers(), params={"fields": fields})
            resp.raise_for_status()
            data = resp.json().get("data", {})
            src = (data.get(SOURCE_FIELD) or "").strip()
            disp = safe_str(data.get(DISPLAY_FIELD))
            if is_numeric_id(src):
                results.append((data["id"], (data.get("name") or "").strip(), src, disp))
            else:
                log.info(f"Company {single_id} {SOURCE_FIELD} = '{src}' — not a numeric ID")
        except Exception as e:
            log.error(f"Failed to fetch company {single_id}: {e}")
        return results

    # Bulk scan via search API
    start = 0
    count = 100
    total_fetched = 0

    log.info("Scanning companies...")

    # Try Lucene search first
    url = f"{client.rest_url}search/ClientCorporation"
    probe = requests.get(url, headers=client.get_headers(),
                         params={"query": f"{SOURCE_FIELD}:[0 TO 99999]",
                                 "fields": fields, "count": 1, "start": 0})

    if probe.status_code == 200 and probe.json().get("total", 0) > 0:
        total = probe.json()["total"]
        log.info(f"  Found {total} companies with numeric {SOURCE_FIELD}")

        while True:
            params = {
                "query": f"{SOURCE_FIELD}:[0 TO 99999]",
                "fields": fields,
                "count": count,
                "start": start
            }
            resp = requests.get(url, headers=client.get_headers(), params=params)
            resp.raise_for_status()
            data = resp.json().get("data", [])

            if not data:
                break

            for company in data:
                src = (company.get(SOURCE_FIELD) or "").strip()
                disp = safe_str(company.get(DISPLAY_FIELD))
                if is_numeric_id(src):
                    results.append((company["id"], (company.get("name") or "").strip(), src, disp))
                total_fetched += 1

            log.info(f"  Scanned {total_fetched} | {len(results)} need processing")

            if len(data) < count:
                break
            start += count
            time.sleep(0.2)
    else:
        # Fallback: query all
        log.info("  Search API unavailable, falling back to full scan...")
        while True:
            qurl = f"{client.rest_url}query/ClientCorporation"
            params = {"where": "id > 0", "fields": fields,
                      "count": count, "start": start, "orderBy": "id"}
            try:
                resp = requests.get(qurl, headers=client.get_headers(), params=params)
                resp.raise_for_status()
                data = resp.json().get("data", [])
                if not data:
                    break
                for company in data:
                    src = (company.get(SOURCE_FIELD) or "").strip()
                    disp = safe_str(company.get(DISPLAY_FIELD))
                    if is_numeric_id(src):
                        results.append((company["id"], (company.get("name") or "").strip(), src, disp))
                    total_fetched += 1
                log.info(f"  Scanned {total_fetched} | {len(results)} need processing")
                if len(data) < count:
                    break
                start += count
                time.sleep(0.2)
            except Exception as e:
                log.error(f"Query failed at start={start}: {e}")
                break

    log.info(f"Scan complete: {len(results)} companies with numeric IDs in {SOURCE_FIELD}")

    # In sync mode, filter to only mismatched records
    if sync_only and results:
        before_count = len(results)
        filtered = []
        for cid, cname, src, disp in results:
            resolved = resolve_user(client, int(src))
            if resolved and resolved != disp:
                filtered.append((cid, cname, src, disp))
            time.sleep(0.05)
        results = filtered
        log.info(f"  Sync filter: {before_count} total → {len(results)} need updating")

    return results


def update_company(client, company_id, display_name, dry_run=True):
    """Update DISPLAY_FIELD (customText6) on a company. Auto-refreshes token on 401."""
    if dry_run:
        return True

    url = f"{client.rest_url}entity/ClientCorporation/{company_id}"
    payload = {DISPLAY_FIELD: display_name}

    for attempt in range(2):
        try:
            resp = requests.post(
                url,
                headers={**client.get_headers(), "Content-Type": "application/json"},
                json=payload
            )
            if resp.status_code == 401 and attempt == 0:
                log.info("  🔄 Session expired, refreshing token...")
                client.connect()
                url = f"{client.rest_url}entity/ClientCorporation/{company_id}"
                continue
            resp.raise_for_status()
            return True
        except requests.exceptions.HTTPError as e:
            if "401" in str(e) and attempt == 0:
                log.info("  🔄 Session expired, refreshing token...")
                client.connect()
                url = f"{client.rest_url}entity/ClientCorporation/{company_id}"
                continue
            log.error(f"Failed to update company {company_id}: {e}")
            return False
        except Exception as e:
            log.error(f"Failed to update company {company_id}: {e}")
            return False
    return False


def main():
    parser = argparse.ArgumentParser(description="Fix Sales Rep header: populate customText6 with resolved names")
    group = parser.add_mutually_exclusive_group()
    group.add_argument("--dry-run", action="store_true", default=True,
                       help="Preview changes without writing (default)")
    group.add_argument("--test-single", type=int, metavar="COMPANY_ID",
                       help="Fix a single company as proof of concept")
    group.add_argument("--execute", action="store_true",
                       help="Execute fixes on ALL affected companies")
    group.add_argument("--sync", action="store_true",
                       help="Sync mode: only fix records where display name is missing/wrong")
    args = parser.parse_args()

    is_dry_run = not args.execute and not args.sync and args.test_single is None
    sync_mode = args.sync
    mode_label = "DRY RUN" if is_dry_run else (
        "TEST SINGLE" if args.test_single else (
            "SYNC" if sync_mode else "EXECUTE"))

    print("=" * 70)
    print(f"  Sales Rep Header Fix  [{mode_label}]")
    print(f"  {SOURCE_FIELD} (ID) → {DISPLAY_FIELD} (Name)")
    print("=" * 70)

    if args.execute:
        print("\n  ⚠️  EXECUTE MODE — this will modify live Bullhorn data!")
        print("  Press Ctrl+C within 5 seconds to abort...")
        try:
            time.sleep(5)
        except KeyboardInterrupt:
            print("\n  Aborted.")
            return

    client = BullhornClient()
    client.connect()
    log.info("Connected to Bullhorn.\n")

    # Fetch companies
    companies = fetch_companies(client, args.test_single, sync_only=sync_mode)

    if not companies:
        print("\n  No companies need fixing. ✅")
        return

    print(f"\n{'─' * 70}")
    print(f"  {len(companies)} companies to process")
    print("─" * 70)

    changes = []
    errors = []

    for i, (company_id, company_name, source_id, current_display) in enumerate(companies, 1):
        user_id = int(source_id)
        resolved_name = resolve_user(client, user_id)

        if resolved_name:
            # Skip if already correct
            if current_display == resolved_name:
                continue

            do_write = not is_dry_run
            success = update_company(client, company_id, resolved_name, dry_run=is_dry_run)
            status = "✅ WILL FIX" if is_dry_run else "✅ FIXED"

            if success:
                changes.append({
                    "company_id": company_id,
                    "company_name": company_name,
                    "source_id": source_id,
                    "old_display": current_display or "(empty)",
                    "new_display": resolved_name,
                })
                print(f"  [{i}/{len(companies)}] {status}: {company_name} (ID:{company_id})")
                print(f"           {DISPLAY_FIELD}: '{current_display or '(empty)'}' → '{resolved_name}'")
            else:
                errors.append((company_id, company_name, "Update failed"))
                print(f"  [{i}/{len(companies)}] ❌ FAILED: {company_name} (ID:{company_id})")
        else:
            errors.append((company_id, company_name, f"CorporateUser {user_id} not found"))
            print(f"  [{i}/{len(companies)}] ⚠️  SKIPPED: {company_name} (ID:{company_id})")
            print(f"           CorporateUser {user_id} could not be resolved")

        time.sleep(0.1)

    # ─── Summary ──────────────────────────────────────────────────────────
    print(f"\n{'=' * 70}")
    print(f"  SUMMARY [{mode_label}]")
    print("=" * 70)
    print(f"  Total scanned:   {len(companies)}")
    print(f"  {'Would fix' if is_dry_run else 'Fixed'}:      {len(changes)}")
    print(f"  Errors/Skipped:  {len(errors)}")

    if errors:
        print(f"\n  Errors:")
        for cid, cname, reason in errors:
            print(f"    - {cname} (ID:{cid}): {reason}")

    # ─── Audit log ────────────────────────────────────────────────────────
    if changes:
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        exports_dir = os.path.join(os.path.dirname(__file__), '..', '..', 'exports')
        os.makedirs(exports_dir, exist_ok=True)

        prefix = "dryrun" if is_dry_run else ("synced" if sync_mode else "fixed")
        csv_path = os.path.join(exports_dir, f"salesrep_{prefix}_{timestamp}.csv")

        with open(csv_path, 'w', newline='') as f:
            writer = csv.DictWriter(f, fieldnames=["company_id", "company_name", "source_id", "old_display", "new_display"])
            writer.writeheader()
            writer.writerows(changes)

        print(f"\n  📄 Audit log: {os.path.abspath(csv_path)}")

    # ─── Verification ─────────────────────────────────────────────────────
    if not is_dry_run and changes:
        print(f"\n{'─' * 70}")
        print("  VERIFICATION: Re-reading updated records")
        print("─" * 70)

        for change in changes[:5]:
            cid = change["company_id"]
            try:
                url = f"{client.rest_url}entity/ClientCorporation/{cid}"
                params = {"fields": f"id,name,{SOURCE_FIELD},{DISPLAY_FIELD}"}
                resp = requests.get(url, headers=client.get_headers(), params=params)
                resp.raise_for_status()
                data = resp.json().get("data", {})
                ct3 = data.get(SOURCE_FIELD, "")
                ct6 = safe_str(data.get(DISPLAY_FIELD))
                expected = change["new_display"]
                match = "✅" if ct6 == expected else "❌"
                print(f"  {match} Company {cid}: {SOURCE_FIELD}='{ct3}' | {DISPLAY_FIELD}='{ct6}'")
            except Exception as e:
                print(f"  ❌ Company {cid}: verification failed: {e}")

    print(f"\n{'=' * 70}")


if __name__ == "__main__":
    main()
