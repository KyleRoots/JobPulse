#!/usr/bin/env python3
"""
Optimized scan: ONLY resume files for candidates truly added in 2025.
- Filters by ID range (4401500-4575000) to target 2025 candidates
- Only checks files of type "Resume" (skips HTML, images, etc.)
- Validates dateAdded client-side as hard guardrail
"""
import sys, os, csv, time
from datetime import datetime
from collections import defaultdict

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), '..'))
import requests
from integrations.bullhorn_client import BullhornClient
import logging
logging.disable(logging.CRITICAL)

OUTPUT_CSV = os.path.expanduser("~/Downloads/corrupt_files_2025.csv")
JAN1_2025 = int(datetime(2025, 1, 1).timestamp() * 1000)
DEC31_2025 = int(datetime(2025, 12, 31, 23, 59, 59).timestamp() * 1000)

# Tight ID range for 2025 candidates
ID_START = 4401500
ID_END = 4575000


def main():
    client = BullhornClient()
    client.connect()
    url = f"{client.rest_url}search/Candidate"

    # Get total count
    params = {
        "query": f"id:[{ID_START} TO {ID_END}] AND isDeleted:0",
        "fields": "id", "count": 1
    }
    resp = requests.get(url, headers=client.get_headers(), params=params, timeout=30)
    total_in_range = resp.json().get("total", 0)

    print(f"{'=' * 60}")
    print(f"OPTIMIZED SCAN — Resume Files Only, 2025 Candidates")
    print(f"{'=' * 60}")
    print(f"ID range:        {ID_START:,} – {ID_END:,}")
    print(f"IDs in range:    {total_in_range:,}")
    print(f"File filter:     Resume type ONLY")
    print(f"Date guardrail:  Jan 1, 2025 – Dec 31, 2025 (strict)")
    print(f"Started:         {datetime.now()}")
    print(f"{'=' * 60}\n", flush=True)

    corrupt_files = []
    stats = {
        "scanned": 0, "in_2025": 0, "not_2025": 0,
        "with_resumes": 0, "no_resumes": 0,
        "resumes_checked": 0, "ok": 0, "corrupt": 0, "empty": 0,
        "non_resume_skipped": 0
    }

    batch_size = 200
    batch_start = 0
    start_time = time.time()
    last_connect = time.time()

    # Write CSV header
    with open(OUTPUT_CSV, "w", newline="") as f:
        csv.writer(f).writerow([
            "Candidate ID", "Candidate Name", "Date Added", "File Name", "Status"
        ])

    while True:
        # Reconnect every 3 minutes
        if time.time() - last_connect > 180:
            try:
                client.connect()
                last_connect = time.time()
            except:
                time.sleep(5)
                continue

        try:
            params = {
                "query": f"id:[{ID_START} TO {ID_END}] AND isDeleted:0",
                "fields": "id,firstName,lastName,dateAdded",
                "count": batch_size, "start": batch_start, "sort": "id"
            }
            resp = requests.get(url, headers=client.get_headers(), params=params, timeout=30)
            if resp.status_code == 401:
                client.connect()
                last_connect = time.time()
                resp = requests.get(url, headers=client.get_headers(), params=params, timeout=30)
            candidates = resp.json().get("data", [])
        except Exception as e:
            print(f"Batch error: {e}", flush=True)
            time.sleep(5)
            continue

        if not candidates:
            break

        for cand in candidates:
            stats["scanned"] += 1
            da = cand.get("dateAdded", 0)

            # HARD GUARDRAIL: skip if not 2025
            if da < JAN1_2025 or da > DEC31_2025:
                stats["not_2025"] += 1
                continue

            stats["in_2025"] += 1
            cid = cand["id"]
            name = f"{cand.get('firstName', '')} {cand.get('lastName', '')}".strip()
            date_str = datetime.fromtimestamp(da / 1000).strftime("%Y-%m-%d")

            # Get file attachments
            files = []
            for attempt in range(3):
                try:
                    fr = requests.get(
                        f"{client.rest_url}entity/Candidate/{cid}/fileAttachments",
                        headers=client.get_headers(),
                        params={"fields": "id,name,type"}, timeout=15
                    )
                    if fr.status_code == 401:
                        client.connect()
                        last_connect = time.time()
                        continue
                    if fr.status_code == 200:
                        files = fr.json().get("data", [])
                    break
                except:
                    time.sleep(1)

            # Filter to RESUME files only
            resumes = [f for f in files if (f.get("type") or "").lower() == "resume"]
            stats["non_resume_skipped"] += len(files) - len(resumes)

            if not resumes:
                stats["no_resumes"] += 1
                continue

            stats["with_resumes"] += 1

            # Check each resume file
            for f in resumes:
                fid = f["id"]
                fname = f.get("name", "unknown")
                stats["resumes_checked"] += 1

                try:
                    dr = requests.get(
                        f"{client.rest_url}file/Candidate/{cid}/{fid}",
                        headers=client.get_headers(), timeout=20
                    )
                    if dr.status_code == 500:
                        stats["corrupt"] += 1
                        with open(OUTPUT_CSV, "a", newline="") as cf:
                            csv.writer(cf).writerow([cid, name, date_str, fname, "Corrupt"])
                        corrupt_files.append({
                            "id": cid, "name": name, "date": date_str, "file": fname
                        })
                        print(f"  CORRUPT: {name} (ID:{cid}, {date_str}) - {fname}", flush=True)
                    elif dr.status_code == 200:
                        if len(dr.content) == 0:
                            stats["empty"] += 1
                            with open(OUTPUT_CSV, "a", newline="") as cf:
                                csv.writer(cf).writerow([cid, name, date_str, fname, "Empty"])
                            corrupt_files.append({
                                "id": cid, "name": name, "date": date_str, "file": fname
                            })
                            print(f"  EMPTY: {name} (ID:{cid}, {date_str}) - {fname}", flush=True)
                        else:
                            stats["ok"] += 1
                    elif dr.status_code == 401:
                        client.connect()
                        last_connect = time.time()
                except:
                    pass

                time.sleep(0.03)

        # Progress every batch
        elapsed = time.time() - start_time
        pct = (stats["scanned"] / max(total_in_range, 1)) * 100
        print(
            f"PROGRESS: {stats['scanned']:,}/{total_in_range:,} ({pct:.1f}%) | "
            f"2025: {stats['in_2025']:,} | "
            f"resumes checked: {stats['resumes_checked']} | "
            f"corrupt: {stats['corrupt']} | "
            f"non-resume skipped: {stats['non_resume_skipped']} | "
            f"{elapsed / 60:.1f}min",
            flush=True
        )

        if stats["scanned"] % 1000 == 0:
            try:
                client.connect()
                last_connect = time.time()
            except:
                pass

        batch_start += len(candidates)

    # SUMMARY
    elapsed = time.time() - start_time
    unique = len(set(c["id"] for c in corrupt_files))

    print(f"\n{'=' * 60}")
    print(f"SCAN COMPLETE — {datetime.now()}")
    print(f"Duration: {elapsed / 60:.1f} minutes")
    print(f"{'=' * 60}")
    print(f"IDs scanned:                {stats['scanned']:,}")
    print(f"  Confirmed 2025:           {stats['in_2025']:,}")
    print(f"  Not 2025 (skipped):       {stats['not_2025']:,}")
    print(f"  With resumes:             {stats['with_resumes']:,}")
    print(f"  Without resumes:          {stats['no_resumes']:,}")
    print(f"Non-resume files skipped:   {stats['non_resume_skipped']:,}")
    print(f"Resumes checked:            {stats['resumes_checked']:,}")
    print(f"  OK:                       {stats['ok']:,}")
    print(f"  CORRUPT:                  {stats['corrupt']:,}")
    print(f"  EMPTY:                    {stats['empty']:,}")
    print(f"Unique candidates affected: {unique}")

    if stats['resumes_checked']:
        rate = (stats['corrupt'] + stats['empty']) / stats['resumes_checked'] * 100
        print(f"Resume corruption rate:     {rate:.2f}%")

    if corrupt_files:
        print(f"\nMONTHLY BREAKDOWN:")
        monthly = defaultdict(int)
        for c in corrupt_files:
            monthly[c["date"][:7]] += 1
        for m in sorted(monthly.keys()):
            print(f"  {m}: {monthly[m]}")

    print(f"\nCSV: {OUTPUT_CSV}")
    print("DONE", flush=True)


if __name__ == "__main__":
    main()
