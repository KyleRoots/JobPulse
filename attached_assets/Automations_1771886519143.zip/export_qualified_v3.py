#!/usr/bin/env python3
"""
Scout Genius - Export Qualified Candidates (v3)

Uses Bullhorn entity association endpoint to fetch notes:
  GET /entity/Candidate/{id}/notes

This is the most reliable way because:
- search/Note (Lucene) doesn't index custom dropdown values
- query/Note doesn't exist (400 error)
- entity association endpoint returns ALL notes regardless of action value

Also fetches MORE notes per candidate (200 instead of 5) to find qualifying ones.

Usage:
    python3 export_qualified_v3.py
"""

import os, sys, csv, time, requests, logging
from datetime import datetime

sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', '..'))
from integrations.bullhorn_client import BullhornClient

logging.basicConfig(level=logging.INFO, format='%(asctime)s [%(levelname)s] %(message)s', datefmt='%H:%M:%S')
logger = logging.getLogger("ExportV3")

# ─── Configuration ───────────────────────────────────────────────────────────

JOB_IDS = [34637, 34638, 34639]

QUALIFYING_ACTIONS = [
    "Scout Screen - Qualified",
    "AI Vetting - Qualified",
    "AI Vetting - Recommended",
    "AI Vetted - Accept",  # Also check predefined versions
]

NOTES_PER_CANDIDATE = 200
SUBMISSIONS_PAGE_SIZE = 500
API_DELAY = 0.12


def get_candidate_notes_via_entity(client, candidate_id):
    """
    Fetch notes using entity association endpoint.
    GET /entity/Candidate/{id}/notes
    This returns ALL notes for the candidate, bypassing Lucene indexing issues.
    """
    url = f"{client.rest_url}entity/Candidate/{candidate_id}/notes"
    params = {
        "fields": "id,action,dateAdded,comments",
        "count": NOTES_PER_CANDIDATE,
        "orderBy": "-dateAdded"
    }
    try:
        resp = requests.get(url, headers=client.get_headers(), params=params)
        resp.raise_for_status()
        data = resp.json()
        
        # Entity association returns under "data" or directly
        if isinstance(data, dict):
            return data.get("data", [])
        return data
    except Exception as e:
        logger.warning(f"Entity notes failed for {candidate_id}: {e}")
        return []


def get_all_submissions(client, job_id):
    """Fetch ALL submissions for a job using search API with pagination."""
    all_submissions = []
    start = 0
    
    while True:
        url = f"{client.rest_url}search/JobSubmission"
        params = {
            "query": f"jobOrder.id:{job_id} AND isDeleted:0",
            "fields": "id,status,dateAdded,candidate(id,firstName,lastName,email,phone,occupation,source)",
            "count": SUBMISSIONS_PAGE_SIZE,
            "start": start,
            "sort": "-dateAdded"
        }
        try:
            resp = requests.get(url, headers=client.get_headers(), params=params)
            resp.raise_for_status()
            data = resp.json()
            records = data.get("data", [])
            total = data.get("total", 0)
            
            if not records:
                break
            
            all_submissions.extend(records)
            start += SUBMISSIONS_PAGE_SIZE
            if start >= total:
                break
            time.sleep(API_DELAY)
        except Exception as e:
            logger.error(f"Submissions fetch failed for job {job_id}: {e}")
            break
    
    return all_submissions


def main():
    print("=" * 70)
    print("  Scout Genius - Export Qualified Candidates (v3)")
    print("  Using Entity Association Endpoint for Notes")
    print("=" * 70)
    print()
    
    client = BullhornClient()
    client.connect()
    logger.info("Connected to Bullhorn.\n")
    
    # ─── Step 0: Quick test — fetch notes for a KNOWN candidate ───────────
    
    print("─" * 70)
    print("  DIAGNOSTIC: Testing entity association endpoint")
    print("─" * 70)
    
    # Pick first candidate from job 34637
    test_url = f"{client.rest_url}search/JobSubmission"
    test_params = {
        "query": "jobOrder.id:34637 AND isDeleted:0",
        "fields": "id,candidate(id,firstName,lastName)",
        "count": 3,
        "sort": "dateAdded"  # Oldest first — more likely to have notes
    }
    resp = requests.get(test_url, headers=client.get_headers(), params=test_params)
    test_subs = resp.json().get("data", [])
    
    for sub in test_subs:
        cand = sub.get("candidate", {})
        cid = cand.get("id")
        print(f"\n  Testing candidate {cid} ({cand.get('firstName')} {cand.get('lastName')}):")
        
        notes = get_candidate_notes_via_entity(client, cid)
        print(f"    Found {len(notes)} notes via entity endpoint")
        
        if notes:
            for n in notes[:5]:
                print(f"    → Action: {repr(n.get('action'))} | Date: {n.get('dateAdded')}")
                # Show first 100 chars of comments  
                comments = n.get("comments", "")
                if comments:
                    print(f"      Comment: {comments[:100]}...")
        else:
            # Try the search approach for comparison
            search_url = f"{client.rest_url}search/Note"
            search_params = {
                "query": f"candidates.id:{cid} AND isDeleted:0",
                "fields": "id,action,dateAdded",
                "count": 10
            }
            sresp = requests.get(search_url, headers=client.get_headers(), params=search_params)
            search_notes = sresp.json().get("data", [])
            print(f"    Search API found: {len(search_notes)} notes")
            for sn in search_notes[:3]:
                print(f"    → Action: {repr(sn.get('action'))}")
        
        time.sleep(API_DELAY)
    
    # ─── Now also test with a candidate we KNOW has the qualifying note ───
    # The user's screenshot showed "Scout Screen - Qualified" in the Notes tab
    # Let's try fetching notes for candidates that have been around longer
    
    print(f"\n\n  Testing OLDEST candidates across all 3 jobs:")
    for job_id in JOB_IDS:
        url = f"{client.rest_url}search/JobSubmission"
        params = {
            "query": f"jobOrder.id:{job_id} AND isDeleted:0",
            "fields": "id,candidate(id,firstName,lastName)",
            "count": 3,
            "sort": "dateAdded"
        }
        resp = requests.get(url, headers=client.get_headers(), params=params)
        subs = resp.json().get("data", [])
        
        for sub in subs:
            cand = sub.get("candidate", {})
            cid = cand.get("id")
            notes = get_candidate_notes_via_entity(client, cid)
            actions = set(n.get("action", "") for n in notes if n.get("action"))
            
            qualifying = [a for a in actions if a in QUALIFYING_ACTIONS]
            marker = " ✅" if qualifying else ""
            
            print(f"  Job {job_id} | Candidate {cid} ({cand.get('firstName')} {cand.get('lastName')}): {len(notes)} notes | Actions: {sorted(actions) if actions else '(none)'}{marker}")
            time.sleep(API_DELAY)
    
    # ─── Step 1: Full scan ────────────────────────────────────────────────
    
    print(f"\n\n{'─' * 70}")
    print("  FULL SCAN: All candidates on jobs 34637, 34638, 34639")
    print("─" * 70)
    
    job_titles = {}
    qualified_candidates = []
    seen = set()
    all_actions_found = set()
    
    for job_id in JOB_IDS:
        job = client.get_job(job_id)
        job_titles[job_id] = job.get("title", f"Job {job_id}") if job else f"Job {job_id}"
        
        submissions = get_all_submissions(client, job_id)
        logger.info(f"Job {job_id} ({job_titles[job_id]}): {len(submissions)} submissions")
        
        qualified_count = 0
        for i, sub in enumerate(submissions):
            cand = sub.get("candidate", {})
            cid = cand.get("id")
            if not cid:
                continue
            
            # Fetch notes via entity endpoint
            notes = get_candidate_notes_via_entity(client, cid)
            time.sleep(API_DELAY)
            
            # Track ALL actions we see
            for n in notes:
                action = n.get("action", "")
                if action:
                    all_actions_found.add(action)
            
            # Check for qualifying actions
            qualifying_notes = [n for n in notes if n.get("action", "").strip() in QUALIFYING_ACTIONS]
            
            if qualifying_notes:
                qualified_count += 1
                actions_found = list(set(n.get("action", "").strip() for n in qualifying_notes))
                
                for action in actions_found:
                    qualified_candidates.append({
                        "candidate_id": cid,
                        "first_name": cand.get("firstName", ""),
                        "last_name": cand.get("lastName", ""),
                        "email": cand.get("email", ""),
                        "phone": cand.get("phone", ""),
                        "source": cand.get("source", ""),
                        "occupation": cand.get("occupation", ""),
                        "job_id": job_id,
                        "job_title": job_titles[job_id],
                        "note_action": action
                    })
                
                logger.info(f"  ✅ [{qualified_count}] {cand.get('firstName')} {cand.get('lastName')} (ID:{cid}) — {', '.join(actions_found)}")
            
            if (i + 1) % 50 == 0:
                logger.info(f"  Scanned {i+1}/{len(submissions)} | {qualified_count} qualified | {len(all_actions_found)} unique actions seen")
        
        logger.info(f"  Job {job_id}: {qualified_count} qualified out of {len(submissions)}\n")
    
    # ─── Results ──────────────────────────────────────────────────────────
    
    print(f"\n{'=' * 70}")
    print("  RESULTS")
    print("=" * 70)
    
    print(f"\n  All unique Note actions found across scanned candidates:")
    for a in sorted(all_actions_found):
        marker = " ← QUALIFYING" if a in QUALIFYING_ACTIONS else ""
        print(f"    {repr(a)}{marker}")
    
    if qualified_candidates:
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        output_dir = os.path.join(os.path.dirname(__file__), '..', '..', 'exports')
        os.makedirs(output_dir, exist_ok=True)
        output_file = os.path.join(output_dir, f"qualified_candidates_{timestamp}.csv")
        
        fieldnames = ["candidate_id", "first_name", "last_name", "email", "phone",
                      "source", "occupation", "job_id", "job_title", "note_action"]
        
        with open(output_file, 'w', newline='', encoding='utf-8') as f:
            writer = csv.DictWriter(f, fieldnames=fieldnames)
            writer.writeheader()
            writer.writerows(qualified_candidates)
        
        unique_ids = set(c["candidate_id"] for c in qualified_candidates)
        print(f"\n  ✅ Total rows: {len(qualified_candidates)}")
        print(f"  ✅ Unique candidates: {len(unique_ids)}")
        
        for job_id in JOB_IDS:
            jc = len([c for c in qualified_candidates if c["job_id"] == job_id])
            print(f"     Job {job_id}: {jc}")
        
        print(f"\n  📄 CSV: {os.path.abspath(output_file)}")
    else:
        print(f"\n  ⚠️  No qualified candidates found.")
        print(f"  Total unique note actions seen: {len(all_actions_found)}")
        print(f"\n  The qualifying actions ({QUALIFYING_ACTIONS})")
        print(f"  were not found in any notes on these candidates.")
    
    print("=" * 70)


if __name__ == "__main__":
    main()
