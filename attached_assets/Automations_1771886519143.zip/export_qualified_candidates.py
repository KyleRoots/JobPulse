#!/usr/bin/env python3
"""
Scout Genius - Export Qualified Candidates to CSV

Queries Bullhorn for candidates associated with specific job IDs that have
notes with action 'Scout Screen - Qualified' or 'AI Vetting - Qualified'.

Output CSV includes: Candidate ID, First Name, Last Name, Email, Job ID, Job Title, Note Action

Usage:
    python3 export_qualified_candidates.py
"""

import os
import sys
import csv
import time
import logging
import requests
from datetime import datetime

# Add parent dirs to path for imports
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', '..'))

from integrations.bullhorn_client import BullhornClient

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s [%(levelname)s] %(message)s',
    datefmt='%H:%M:%S'
)
logger = logging.getLogger("ExportQualified")

# ─── Configuration ───────────────────────────────────────────────────────────

JOB_IDS = [34637, 34638, 34639]

QUALIFYING_ACTIONS = [
    "Scout Screen - Qualified",
    "AI Vetting - Qualified"
]

# How many submissions to fetch per API call (Bullhorn max is 500)
SUBMISSIONS_PAGE_SIZE = 200

# How many notes to fetch per candidate (increase if a candidate might have many notes)
NOTES_COUNT = 50

# Rate limiting: pause between API calls to avoid throttling
API_DELAY = 0.1  # seconds


# ─── Helper Functions ────────────────────────────────────────────────────────

def get_all_submissions(client, job_id):
    """Fetch ALL submissions for a job, handling pagination."""
    all_submissions = []
    start = 0
    
    while True:
        url = f"{client.rest_url}search/JobSubmission"
        query = f"jobOrder.id:{job_id} AND isDeleted:0"
        fields = "id,status,dateAdded,candidate(id,firstName,lastName,email,phone,occupation,status)"
        
        params = {
            "query": query,
            "fields": fields,
            "count": SUBMISSIONS_PAGE_SIZE,
            "start": start,
            "sort": "-dateAdded"
        }
        
        try:
            resp = requests.get(url, headers=client.get_headers(), params=params)
            resp.raise_for_status()
            data = resp.json()
            
            records = data.get("data", [])
            total = data.get("total", 0)
            
            if not records:
                break
                
            all_submissions.extend(records)
            logger.info(f"  Fetched {len(all_submissions)}/{total} submissions for job {job_id}")
            
            start += SUBMISSIONS_PAGE_SIZE
            if start >= total:
                break
                
            time.sleep(API_DELAY)
            
        except Exception as e:
            logger.error(f"Failed to fetch submissions for job {job_id} (start={start}): {e}")
            break
    
    return all_submissions


def get_candidate_notes(client, candidate_id, count=NOTES_COUNT):
    """Fetch notes for a candidate with qualifying action filter."""
    # Build Lucene query to search for notes with specific actions
    # We'll fetch more notes and filter client-side for reliability
    url = f"{client.rest_url}search/Note"
    query = f"candidates.id:{candidate_id} AND isDeleted:0"
    
    params = {
        "query": query,
        "fields": "id,action,dateAdded,comments,commentingPerson(id,firstName,lastName)",
        "count": count,
        "sort": "-dateAdded"
    }
    
    try:
        resp = requests.get(url, headers=client.get_headers(), params=params)
        resp.raise_for_status()
        return resp.json().get("data", [])
    except Exception as e:
        logger.warning(f"Failed to fetch notes for candidate {candidate_id}: {e}")
        return []


def get_job_title(client, job_id):
    """Fetch the job title for a given job ID."""
    try:
        job = client.get_job(job_id)
        if job:
            return job.get("title", f"Job {job_id}")
    except Exception as e:
        logger.warning(f"Could not fetch title for job {job_id}: {e}")
    return f"Job {job_id}"


# ─── Main Export Logic ───────────────────────────────────────────────────────

def main():
    print("=" * 70)
    print("  Scout Genius - Export Qualified Candidates")
    print("=" * 70)
    print()
    
    # Connect to Bullhorn
    logger.info("Connecting to Bullhorn API...")
    client = BullhornClient()
    client.connect()
    logger.info("Connected successfully.\n")
    
    # Get job titles
    job_titles = {}
    for job_id in JOB_IDS:
        job_titles[job_id] = get_job_title(client, job_id)
        logger.info(f"Job {job_id}: {job_titles[job_id]}")
        time.sleep(API_DELAY)
    
    print()
    
    # Collect all qualified candidates
    qualified_candidates = []
    seen_candidate_ids = set()  # Track across jobs to note duplicates
    
    for job_id in JOB_IDS:
        job_title = job_titles[job_id]
        logger.info(f"Processing Job {job_id}: {job_title}")
        
        # Fetch all submissions for this job
        submissions = get_all_submissions(client, job_id)
        logger.info(f"  Total submissions: {len(submissions)}")
        
        # Check each candidate's notes
        qualified_count = 0
        for i, sub in enumerate(submissions):
            candidate = sub.get("candidate", {})
            if not candidate or not candidate.get("id"):
                continue
            
            cand_id = candidate["id"]
            cand_first = candidate.get("firstName", "")
            cand_last = candidate.get("lastName", "")
            cand_email = candidate.get("email", "")
            
            # Fetch notes for this candidate
            notes = get_candidate_notes(client, cand_id)
            time.sleep(API_DELAY)
            
            # Check for qualifying note actions
            qualifying_notes = [
                n for n in notes 
                if n.get("action", "").strip() in QUALIFYING_ACTIONS
            ]
            
            if qualifying_notes:
                qualified_count += 1
                # Determine which qualifying action(s) this candidate has
                actions_found = list(set(n.get("action", "").strip() for n in qualifying_notes))
                
                is_duplicate = cand_id in seen_candidate_ids
                seen_candidate_ids.add(cand_id)
                
                for action in actions_found:
                    qualified_candidates.append({
                        "candidate_id": cand_id,
                        "first_name": cand_first,
                        "last_name": cand_last,
                        "email": cand_email,
                        "job_id": job_id,
                        "job_title": job_title,
                        "note_action": action,
                        "duplicate_across_jobs": "Yes" if is_duplicate else "No"
                    })
                
                logger.info(f"  ✅ [{qualified_count}] {cand_first} {cand_last} (ID: {cand_id}) — {', '.join(actions_found)}")
            
            # Progress indicator every 50 candidates
            if (i + 1) % 50 == 0:
                logger.info(f"  Scanned {i + 1}/{len(submissions)} candidates... ({qualified_count} qualified so far)")
        
        logger.info(f"  Finished job {job_id}: {qualified_count} qualified out of {len(submissions)} submissions\n")
    
    # ─── Export to CSV ───────────────────────────────────────────────────
    
    if not qualified_candidates:
        logger.warning("No qualified candidates found. No CSV created.")
        return
    
    # Generate output filename with timestamp
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    output_dir = os.path.join(os.path.dirname(__file__), '..', '..', 'exports')
    os.makedirs(output_dir, exist_ok=True)
    output_file = os.path.join(output_dir, f"qualified_candidates_{timestamp}.csv")
    
    # Write CSV
    fieldnames = [
        "candidate_id", "first_name", "last_name", "email",
        "job_id", "job_title", "note_action", "duplicate_across_jobs"
    ]
    
    with open(output_file, 'w', newline='', encoding='utf-8') as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(qualified_candidates)
    
    # ─── Summary ─────────────────────────────────────────────────────────
    
    print()
    print("=" * 70)
    print("  EXPORT COMPLETE")
    print("=" * 70)
    print(f"  Total qualified candidates: {len(qualified_candidates)}")
    print(f"  Unique candidate IDs: {len(seen_candidate_ids)}")
    print()
    
    # Per-job breakdown
    for job_id in JOB_IDS:
        job_count = len([c for c in qualified_candidates if c["job_id"] == job_id])
        print(f"  Job {job_id} ({job_titles[job_id]}): {job_count} qualified")
    
    print()
    
    # Per-action breakdown
    for action in QUALIFYING_ACTIONS:
        action_count = len([c for c in qualified_candidates if c["note_action"] == action])
        print(f"  {action}: {action_count} candidates")
    
    print()
    print(f"  📄 CSV saved to: {os.path.abspath(output_file)}")
    print("=" * 70)


if __name__ == "__main__":
    main()
