"""
Entry point for the Job Application App
Follows Replit convention with main.py as the launcher
"""

from app import app

if __name__ == '__main__':
    app.run()